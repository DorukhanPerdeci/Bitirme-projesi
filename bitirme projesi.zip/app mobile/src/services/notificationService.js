/**
 * Service for notification operations
 */

import * as api from './api';
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit as firestoreLimit,
  updateDoc,
  deleteDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { db, auth } from './firebase/config';

// Notifications collection reference
const notificationsCollection = collection(db, 'notifications');

/**
 * Retrieves user notifications
 * @param {object} params - Filtering parameters
 * @returns {Promise<object>} Notification list and pagination information
 */
export const getNotifications = async (params = {}) => {
  try {
    const { page = 1, limit = 20, read } = params;
    const limitCount = parseInt(limit);
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    let notificationsQuery = query(
      notificationsCollection,
      where('user_id', '==', currentUser.uid),
      orderBy('created_at', 'desc'),
      firestoreLimit(limitCount)
    );

    // Filter by read status
    if (read !== undefined) {
      notificationsQuery = query(
        notificationsCollection,
        where('user_id', '==', currentUser.uid),
        where('is_read', '==', read),
        orderBy('created_at', 'desc'),
        firestoreLimit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(notificationsQuery);
    const notifications = [];
    
    querySnapshot.forEach((doc) => {
      notifications.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        title: doc.data().title,
        body: doc.data().content,
        type: doc.data().type,
        read: doc.data().is_read,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });
    
    // Find total notifications and unread notifications count
    const totalQuery = query(
      notificationsCollection, 
      where('user_id', '==', currentUser.uid)
    );
    const unreadQuery = query(
      notificationsCollection, 
      where('user_id', '==', currentUser.uid),
      where('is_read', '==', false)
    );
    
    const totalSnapshot = await getDocs(totalQuery);
    const unreadSnapshot = await getDocs(unreadQuery);
    
    return {
      data: notifications,
      pagination: {
        total: totalSnapshot.size,
        page,
        limit: limitCount,
        pages: Math.ceil(totalSnapshot.size / limitCount),
      },
      unreadCount: unreadSnapshot.size
    };
  } catch (error) {
    console.error('Error retrieving notifications:', error);
    throw error;
  }
};

/**
 * Marks a notification as read
 * @param {string} notificationId - Notification ID
 * @returns {Promise<object>} Operation result
 */
export const markAsRead = async (notificationId) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const notificationRef = doc(db, 'notifications', notificationId);
    const notificationDoc = await getDoc(notificationRef);

    // Check if notification belongs to the user
    if (notificationDoc.data()?.user_id !== currentUser.uid) {
      throw new Error('You do not have permission to mark this notification');
    }

    await updateDoc(notificationRef, {
      is_read: true,
      updated_at: serverTimestamp()
    });

    return { 
      success: true, 
      message: 'Notification marked as read' 
    };
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
};

/**
 * Marks all notifications as read
 * @returns {Promise<object>} Operation result
 */
export const markAllAsRead = async () => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const unreadQuery = query(
      notificationsCollection, 
      where('user_id', '==', currentUser.uid),
      where('is_read', '==', false)
    );

    const unreadSnapshot = await getDocs(unreadQuery);

    // Batch update
    const batch = [];
    unreadSnapshot.forEach((doc) => {
      batch.push(
        updateDoc(doc.ref, {
          is_read: true,
          updated_at: serverTimestamp()
        })
      );
    });

    await Promise.all(batch);

    return { 
      success: true, 
      message: 'All notifications marked as read',
      updatedCount: unreadSnapshot.size
    };
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    throw error;
  }
};

/**
 * Deletes a notification
 * @param {string} notificationId - Notification ID
 * @returns {Promise<object>} Operation result
 */
export const deleteNotification = async (notificationId) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const notificationRef = doc(db, 'notifications', notificationId);
    const notificationDoc = await getDoc(notificationRef);

    // Check if notification belongs to the user
    if (notificationDoc.data()?.user_id !== currentUser.uid) {
      throw new Error('You do not have permission to delete this notification');
    }

    await deleteDoc(notificationRef);

    return { 
      success: true, 
      message: 'Notification deleted' 
    };
  } catch (error) {
    console.error('Error deleting notification:', error);
    throw error;
  }
};

/**
 * Deletes all notifications
 * @returns {Promise<object>} Operation result
 */
export const deleteAllNotifications = async () => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const userNotificationsQuery = query(
      notificationsCollection,
      where('user_id', '==', currentUser.uid)
    );

    const querySnapshot = await getDocs(userNotificationsQuery);
    const batch = [];

    querySnapshot.forEach((doc) => {
      batch.push(deleteDoc(doc.ref));
    });

    await Promise.all(batch);

    return { 
      success: true, 
      message: 'All notifications deleted',
      deletedCount: querySnapshot.size 
    };
  } catch (error) {
    console.error('Error deleting all notifications:', error);
    throw error;
  }
};

import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit,
  startAfter,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './config';

// Influencers collection reference
const influencersCollection = collection(db, 'influencers');

/**
 * Retrieves all influencers
 * @param {number} limitCount - Pagination limit
 * @param {Object} lastDoc - Last document (for pagination)
 * @returns {Promise} - Influencer list
 */
export const getAllInfluencers = async (limitCount = 10, lastDoc = null) => {
  try {
    let influencersQuery;
    
    if (lastDoc) {
      influencersQuery = query(
        influencersCollection,
        orderBy('followers_count', 'desc'),
        startAfter(lastDoc),
        limit(limitCount)
      );
    } else {
      influencersQuery = query(
        influencersCollection,
        orderBy('followers_count', 'desc'),
        limit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(influencersQuery);
    const influencers = [];
    
    querySnapshot.forEach((doc) => {
      influencers.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    const lastVisible = querySnapshot.docs[querySnapshot.docs.length - 1];
    
    return { 
      influencers, 
      lastDoc: lastVisible, 
      error: null 
    };
  } catch (error) {
    console.error('Error retrieving influencers:', error);
    return { influencers: [], lastDoc: null, error: error.message };
  }
};

/**
 * Retrieves top influencers
 * @param {number} limitCount - Pagination limit
 * @returns {Promise} - Top influencer list
 */
export const getTopInfluencers = async (limitCount = 3) => {
  try {
    const topQuery = query(
      influencersCollection,
      orderBy('followers_count', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(topQuery);
    const influencers = [];
    
    querySnapshot.forEach((doc) => {
      influencers.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { influencers, error: null };
  } catch (error) {
    console.error('Error retrieving top influencers:', error);
    return { influencers: [], error: error.message };
  }
};

/**
 * Retrieves influencers by category
 * @param {string} category - Category name
 * @param {number} limitCount - Pagination limit
 * @returns {Promise} - Category influencer list
 */
export const getInfluencersByCategory = async (category, limitCount = 10) => {
  try {
    const categoryQuery = query(
      influencersCollection,
      where('category', '==', category),
      orderBy('followers_count', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(categoryQuery);
    const influencers = [];
    
    querySnapshot.forEach((doc) => {
      influencers.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { influencers, error: null };
  } catch (error) {
    console.error('Error retrieving category influencers:', error);
    return { influencers: [], error: error.message };
  }
};

/**
 * Retrieves influencer details
 * @param {string} influencerId - Influencer ID
 * @returns {Promise} - Influencer details
 */
export const getInfluencerDetails = async (influencerId) => {
  try {
    const influencerRef = doc(influencersCollection, influencerId);
    const influencerSnap = await getDoc(influencerRef);
    
    if (influencerSnap.exists()) {
      return { 
        influencer: {
          id: influencerSnap.id,
          ...influencerSnap.data()
        }, 
        error: null 
      };
    } else {
      return { influencer: null, error: 'Influencer not found' };
    }
  } catch (error) {
    console.error('Error retrieving influencer details:', error);
    return { influencer: null, error: error.message };
  }
};

/**
 * Retrieves influencers for a specific campaign
 * @param {Array} influencerIds - Influencer IDs
 * @returns {Promise} - Campaign influencer list
 */
export const getCampaignInfluencers = async (influencerIds) => {
  try {
    const influencers = [];
    
    // Retrieve document for each influencer ID
    for (const id of influencerIds) {
      const influencerRef = doc(influencersCollection, id);
      const influencerSnap = await getDoc(influencerRef);
      
      if (influencerSnap.exists()) {
        influencers.push({
          id: influencerSnap.id,
          ...influencerSnap.data()
        });
      }
    }
    
    return { influencers, error: null };
  } catch (error) {
    console.error('Error retrieving campaign influencers:', error);
    return { influencers: [], error: error.message };
  }
};

/**
 * Searches influencers
 * @param {string} searchQuery - Search text
 * @returns {Promise} - Search results
 */
export const searchInfluencers = async (searchQuery) => {
  try {
    // Note: Firestore does not support full-text search
    // so we're doing a simple search. For more advanced
    // search functionality, consider using a service like Algolia.
    const querySnapshot = await getDocs(influencersCollection);
    const influencers = [];
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      const searchableText = `${data.name} ${data.username} ${data.category} ${data.bio}`.toLowerCase();
      
      if (searchableText.includes(searchQuery.toLowerCase())) {
        influencers.push({
          id: doc.id,
          ...data
        });
      }
    });
    
    return { influencers, error: null };
  } catch (error) {
    console.error('Error searching influencers:', error);
    return { influencers: [], error: error.message };
  }
};

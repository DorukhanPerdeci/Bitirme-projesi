import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { db } from './config';

// Categories collection reference
const categoriesCollection = collection(db, 'categories');

/**
 * Retrieves all categories
 * @returns {Promise} - Category list
 */
export const getAllCategories = async () => {
  try {
    const categoriesQuery = query(
      categoriesCollection,
      orderBy('order', 'asc')
    );
    
    const querySnapshot = await getDocs(categoriesQuery);
    const categories = [];
    
    querySnapshot.forEach((doc) => {
      categories.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { categories, error: null };
  } catch (error) {
    console.error('Error retrieving categories:', error);
    return { categories: [], error: error.message };
  }
};

/**
 * Retrieves popular categories
 * @param {number} limitCount - Pagination limit
 * @returns {Promise} - Popular category list
 */
export const getPopularCategories = async (limitCount = 5) => {
  try {
    const popularQuery = query(
      categoriesCollection,
      orderBy('popularity', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(popularQuery);
    const categories = [];
    
    querySnapshot.forEach((doc) => {
      categories.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { categories, error: null };
  } catch (error) {
    console.error('Error retrieving popular categories:', error);
    return { categories: [], error: error.message };
  }
};

/**
 * Retrieves category details
 * @param {string} categoryId - Category ID
 * @returns {Promise} - Category details
 */
export const getCategoryDetails = async (categoryId) => {
  try {
    const categoryRef = doc(categoriesCollection, categoryId);
    const categorySnap = await getDoc(categoryRef);
    
    if (categorySnap.exists()) {
      return { 
        category: {
          id: categorySnap.id,
          ...categorySnap.data()
        }, 
        error: null 
      };
    } else {
      return { category: null, error: 'Category not found' };
    }
  } catch (error) {
    console.error('Error retrieving category details:', error);
    return { category: null, error: error.message };
  }
};

/**
 * Retrieves subcategories for a specific parent category
 * @param {string} parentId - Parent category ID
 * @returns {Promise} - Subcategory list
 */
export const getSubcategories = async (parentId) => {
  try {
    const subcategoriesQuery = query(
      categoriesCollection,
      where('parent_category_id', '==', parentId),
      orderBy('order', 'asc')
    );
    
    const querySnapshot = await getDocs(subcategoriesQuery);
    const subcategories = [];
    
    querySnapshot.forEach((doc) => {
      subcategories.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { subcategories, error: null };
  } catch (error) {
    console.error('Error retrieving subcategories:', error);
    return { subcategories: [], error: error.message };
  }
};

/**
 * Searches categories
 * @param {string} searchQuery - Search text
 * @returns {Promise} - Search results
 */
export const searchCategories = async (searchQuery) => {
  try {
    // Note: Firestore does not support full-text search
    // so we're doing a simple search. For more advanced
    // search functionality, consider using a service like Algolia.
    const querySnapshot = await getDocs(categoriesCollection);
    const categories = [];
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      const searchableText = `${data.name} ${data.description || ''}`.toLowerCase();
      
      if (searchableText.includes(searchQuery.toLowerCase())) {
        categories.push({
          id: doc.id,
          ...data
        });
      }
    });
    
    return { categories, error: null };
  } catch (error) {
    console.error('Error searching categories:', error);
    return { categories: [], error: error.message };
  }
};

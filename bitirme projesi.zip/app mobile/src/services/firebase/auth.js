import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail,
  updateProfile,
  GoogleAuthProvider,
  FacebookAuthProvider,
  signInWithPopup,
  onAuthStateChanged
} from 'firebase/auth';
import { auth } from './config';

/**
 * Registers a new user
 * @param {string} email - User email address
 * @param {string} password - User password
 * @param {string} displayName - User display name
 * @returns {Promise<{user: Object, error: string|null}>} - Registration result
 */
export const register = async (email, password, displayName) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    
    // Update user profile information
    await updateProfile(userCredential.user, {
      displayName: displayName
    });
    
    return { user: userCredential.user, error: null };
  } catch (error) {
    return { user: null, error: translateFirebaseError(error) };
  }
};

/**
 * Logs in a user
 * @param {string} email - User email address
 * @param {string} password - User password
 * @returns {Promise<{user: Object, error: string|null}>} - Login result
 */
export const login = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { user: userCredential.user, error: null };
  } catch (error) {
    return { user: null, error: translateFirebaseError(error) };
  }
};

/**
 * Logs out the current user
 * @returns {Promise<{success: boolean, error: string|null}>} - Logout result
 */
export const logout = async () => {
  try {
    await signOut(auth);
    return { success: true, error: null };
  } catch (error) {
    return { success: false, error: translateFirebaseError(error) };
  }
};

/**
 * Sends a password reset email
 * @param {string} email - User email address
 * @returns {Promise<{success: boolean, error: string|null}>} - Password reset result
 */
export const resetPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return { success: true, error: null };
  } catch (error) {
    return { success: false, error: translateFirebaseError(error) };
  }
};

/**
 * Logs in with Google authentication
 * @returns {Promise<{user: Object, error: string|null}>} - Google login result
 */
export const loginWithGoogle = async () => {
  try {
    const provider = new GoogleAuthProvider();
    const userCredential = await signInWithPopup(auth, provider);
    return { user: userCredential.user, error: null };
  } catch (error) {
    return { user: null, error: translateFirebaseError(error) };
  }
};

/**
 * Logs in with Facebook authentication
 * @returns {Promise<{user: Object, error: string|null}>} - Facebook login result
 */
export const loginWithFacebook = async () => {
  try {
    const provider = new FacebookAuthProvider();
    const userCredential = await signInWithPopup(auth, provider);
    return { user: userCredential.user, error: null };
  } catch (error) {
    return { user: null, error: translateFirebaseError(error) };
  }
};

/**
 * Subscribes to authentication state changes
 * @param {Function} callback - Function to be called when auth state changes
 * @returns {Function} - Function to unsubscribe from auth state changes
 */
export const subscribeToAuthChanges = (callback) => {
  return onAuthStateChanged(auth, (user) => {
    callback(user);
  });
};

/**
 * Translates Firebase error codes to user-friendly error messages
 * @param {Object} error - Firebase error object
 * @returns {string} - Translated error message
 */
const translateFirebaseError = (error) => {
  const errorCode = error.code;
  
  switch (errorCode) {
    case 'auth/email-already-in-use':
      return 'This email address is already in use.';
    case 'auth/invalid-email':
      return 'Invalid email address.';
    case 'auth/user-disabled':
      return 'This user account has been disabled.';
    case 'auth/user-not-found':
      return 'No user found with this email address.';
    case 'auth/wrong-password':
      return 'Incorrect password.';
    case 'auth/weak-password':
      return 'Password is too weak. Use at least 6 characters.';
    case 'auth/operation-not-allowed':
      return 'This operation is not allowed at the moment.';
    case 'auth/account-exists-with-different-credential':
      return 'This email address is already in use with a different login method.';
    case 'auth/invalid-credential':
      return 'Invalid credentials.';
    case 'auth/invalid-verification-code':
      return 'Invalid verification code.';
    case 'auth/invalid-verification-id':
      return 'Invalid verification ID.';
    case 'auth/requires-recent-login':
      return 'You need to log in recently to perform this action.';
    case 'auth/too-many-requests':
      return 'Your account has been temporarily blocked due to too many failed login attempts. Please try again later.';
    default:
      return `An error occurred: ${error.message}`;
  }
};

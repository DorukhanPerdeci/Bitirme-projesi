import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  query, 
  where, 
  getDocs,
  serverTimestamp
} from 'firebase/firestore';
import { db } from './config';

// Users collection reference
const usersCollection = collection(db, 'users');

/**
 * Creates a new user profile
 * @param {string} userId - User ID
 * @param {Object} userData - User data
 * @returns {Promise} - Operation result
 */
export const createUserProfile = async (userId, userData) => {
  try {
    const userRef = doc(usersCollection, userId);
    
    const userProfile = {
      ...userData,
      created_at: serverTimestamp(),
      updated_at: serverTimestamp(),
      saved_campaigns: [],
      followed_influencers: [],
      notification_preferences: {
        new_campaigns: true,
        ending_campaigns: true,
        new_influencers: true,
        special_offers: true
      }
    };
    
    await setDoc(userRef, userProfile);
    return { success: true, error: null };
  } catch (error) {
    console.error('User profile creation error:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Retrieves user profile
 * @param {string} userId - User ID
 * @returns {Promise} - User profile
 */
export const getUserProfile = async (userId) => {
  try {
    const userRef = doc(usersCollection, userId);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      return { profile: userSnap.data(), error: null };
    } else {
      return { profile: null, error: 'User profile not found' };
    }
  } catch (error) {
    console.error('User profile retrieval error:', error);
    return { profile: null, error: error.message };
  }
};

/**
 * Updates user profile
 * @param {string} userId - User ID
 * @param {Object} userData - User data to update
 * @returns {Promise} - Operation result
 */
export const updateUserProfile = async (userId, userData) => {
  try {
    const userRef = doc(usersCollection, userId);
    
    const updatedData = {
      ...userData,
      updated_at: serverTimestamp()
    };
    
    await updateDoc(userRef, updatedData);
    return { success: true, error: null };
  } catch (error) {
    console.error('User profile update error:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Saves/favorites a campaign for the user
 * @param {string} userId - User ID
 * @param {string} campaignId - Campaign ID
 * @returns {Promise} - Operation result
 */
export const saveCampaign = async (userId, campaignId) => {
  try {
    const userRef = doc(usersCollection, userId);
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      return { success: false, error: 'User profile not found' };
    }
    
    const userData = userSnap.data();
    const savedCampaigns = userData.saved_campaigns || [];
    
    // Check if campaign is already saved
    if (savedCampaigns.includes(campaignId)) {
      // Remove campaign (toggle operation)
      const updatedCampaigns = savedCampaigns.filter(id => id !== campaignId);
      await updateDoc(userRef, { 
        saved_campaigns: updatedCampaigns,
        updated_at: serverTimestamp()
      });
      return { success: true, saved: false, error: null };
    } else {
      // Add campaign
      const updatedCampaigns = [...savedCampaigns, campaignId];
      await updateDoc(userRef, { 
        saved_campaigns: updatedCampaigns,
        updated_at: serverTimestamp()
      });
      return { success: true, saved: true, error: null };
    }
  } catch (error) {
    console.error('Campaign saving error:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Follows/unfollows an influencer
 * @param {string} userId - User ID
 * @param {string} influencerId - Influencer ID
 * @returns {Promise} - Operation result
 */
export const followInfluencer = async (userId, influencerId) => {
  try {
    const userRef = doc(usersCollection, userId);
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      return { success: false, error: 'User profile not found' };
    }
    
    const userData = userSnap.data();
    const followedInfluencers = userData.followed_influencers || [];
    
    // Check if influencer is already followed
    if (followedInfluencers.includes(influencerId)) {
      // Unfollow influencer (toggle operation)
      const updatedInfluencers = followedInfluencers.filter(id => id !== influencerId);
      await updateDoc(userRef, { 
        followed_influencers: updatedInfluencers,
        updated_at: serverTimestamp()
      });
      return { success: true, followed: false, error: null };
    } else {
      // Follow influencer
      const updatedInfluencers = [...followedInfluencers, influencerId];
      await updateDoc(userRef, { 
        followed_influencers: updatedInfluencers,
        updated_at: serverTimestamp()
      });
      return { success: true, followed: true, error: null };
    }
  } catch (error) {
    console.error('Influencer follow error:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Updates user notification preferences
 * @param {string} userId - User ID
 * @param {Object} preferences - Notification preferences
 * @returns {Promise} - Operation result
 */
export const updateNotificationPreferences = async (userId, preferences) => {
  try {
    const userRef = doc(usersCollection, userId);
    
    await updateDoc(userRef, { 
      notification_preferences: preferences,
      updated_at: serverTimestamp()
    });
    
    return { success: true, error: null };
  } catch (error) {
    console.error('Notification preferences update error:', error);
    return { success: false, error: error.message };
  }
};

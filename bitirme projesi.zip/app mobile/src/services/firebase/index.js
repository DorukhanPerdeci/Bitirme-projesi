/**
 * Centralized Firebase Services Exports
 * 
 * This module provides a single point of import for all Firebase-related services
 * Allows easy and clean imports across the application
 */

// Firebase Configuration and Core Services
export * from './config';

// Authentication Services
export * from './auth';

// User-related Services
export * from './users';

// Campaign Management Services
export * from './campaigns';

// Influencer Management Services
export * from './influencers';

// Notification Services
export * from './notifications';

// Category Management Services
export * from './categories';

/**
 * Usage Examples:
 * 
 * Import specific services:
 * import { signIn, getCampaigns, getInfluencers } from '@/services/firebase';
 * 
 * Or import all services:
 * import * as FirebaseServices from '@/services/firebase';
 */

import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc,
  updateDoc,
  deleteDoc,
  query, 
  where, 
  orderBy, 
  limit,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './config';

// Notifications collection reference
const notificationsCollection = collection(db, 'notifications');

/**
 * Retrieves user notifications
 * @param {string} userId - User ID
 * @param {Object} [options] - Optional filtering and pagination
 * @param {number} [options.limit=20] - Maximum number of notifications to retrieve
 * @param {boolean} [options.onlyUnread=false] - Retrieve only unread notifications
 * @returns {Promise<{notifications: Array, error: string|null}>} Notification retrieval result
 */
export const getUserNotifications = async (userId, options = {}) => {
  try {
    const { limit: limitCount = 20, onlyUnread = false } = options;
    
    let notificationsQuery = query(
      notificationsCollection,
      where('user_id', '==', userId),
      orderBy('date', 'desc'),
      limit(limitCount)
    );
    
    if (onlyUnread) {
      notificationsQuery = query(
        notificationsCollection,
        where('user_id', '==', userId),
        where('is_read', '==', false),
        orderBy('date', 'desc'),
        limit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(notificationsQuery);
    const notifications = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { notifications, error: null };
  } catch (error) {
    console.error('Error retrieving notifications:', error);
    return { notifications: [], error: error.message };
  }
};

/**
 * Retrieves unread notifications count
 * @param {string} userId - User ID
 * @returns {Promise<{count: number, error: string|null}>} Unread notifications count
 */
export const getUnreadNotificationsCount = async (userId) => {
  try {
    const unreadQuery = query(
      notificationsCollection,
      where('user_id', '==', userId),
      where('is_read', '==', false)
    );
    
    const querySnapshot = await getDocs(unreadQuery);
    
    return { count: querySnapshot.size, error: null };
  } catch (error) {
    console.error('Error retrieving unread notifications count:', error);
    return { count: 0, error: error.message };
  }
};

/**
 * Marks notification as read
 * @param {string} notificationId - Notification ID
 * @returns {Promise<{success: boolean, error: string|null}>} Operation result
 */
export const markNotificationAsRead = async (notificationId) => {
  try {
    const notificationRef = doc(notificationsCollection, notificationId);
    
    await updateDoc(notificationRef, { 
      is_read: true,
      updated_at: serverTimestamp()
    });
    
    return { success: true, error: null };
  } catch (error) {
    console.error('Error marking notification as read:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Marks all notifications as read
 * @param {string} userId - User ID
 * @returns {Promise<{success: boolean, count: number, error: string|null}>} Operation result
 */
export const markAllNotificationsAsRead = async (userId) => {
  try {
    const unreadQuery = query(
      notificationsCollection,
      where('user_id', '==', userId),
      where('is_read', '==', false)
    );
    
    const querySnapshot = await getDocs(unreadQuery);
    const batch = [];
    
    querySnapshot.forEach((doc) => {
      const notificationRef = doc.ref;
      batch.push(updateDoc(notificationRef, { 
        is_read: true,
        updated_at: serverTimestamp()
      }));
    });
    
    await Promise.all(batch);
    
    return { success: true, count: querySnapshot.size, error: null };
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    return { success: false, count: 0, error: error.message };
  }
};

/**
 * Deletes a notification
 * @param {string} notificationId - Notification ID
 * @returns {Promise<{success: boolean, error: string|null}>} Operation result
 */
export const deleteNotification = async (notificationId) => {
  try {
    const notificationRef = doc(notificationsCollection, notificationId);
    
    await deleteDoc(notificationRef);
    
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting notification:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Deletes all notifications
 * @param {string} userId - User ID
 * @returns {Promise<{success: boolean, count: number, error: string|null}>} Operation result
 */
export const deleteAllNotifications = async (userId) => {
  try {
    const userNotificationsQuery = query(
      notificationsCollection,
      where('user_id', '==', userId)
    );
    
    const querySnapshot = await getDocs(userNotificationsQuery);
    const batch = [];
    
    querySnapshot.forEach((doc) => {
      batch.push(deleteDoc(doc.ref));
    });
    
    await Promise.all(batch);
    
    return { success: true, count: querySnapshot.size, error: null };
  } catch (error) {
    console.error('Error deleting all notifications:', error);
    return { success: false, count: 0, error: error.message };
  }
};

/**
 * Creates a new notification
 * @param {Object} notificationData - Notification data
 * @returns {Promise<{success: boolean, notificationId: string|null, error: string|null}>} Operation result
 */
export const createNotification = async (notificationData) => {
  try {
    const notification = {
      ...notificationData,
      is_read: false,
      date: serverTimestamp(),
      created_at: serverTimestamp()
    };
    
    const docRef = await addDoc(notificationsCollection, notification);
    
    return { 
      success: true, 
      notificationId: docRef.id, 
      error: null 
    };
  } catch (error) {
    console.error('Error creating notification:', error);
    return { success: false, notificationId: null, error: error.message };
  }
};

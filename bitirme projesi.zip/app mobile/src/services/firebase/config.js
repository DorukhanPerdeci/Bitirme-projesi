import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

/**
 * Firebase Configuration
 * 
 * WARNING: 
 * - Hardcoded configuration for development
 * - Do not commit sensitive credentials to version control
 */
const firebaseConfig = {
  apiKey: "AIzaSyD47YnhTe4ikGTnv7X3PPpzH1NsZs6Ltnc",
  authDomain: "slash-app-dc4d1.firebaseapp.com",
  projectId: "slash-app-dc4d1",
  storageBucket: "slash-app-dc4d1.firebasestorage.app",
  messagingSenderId: "403111331493",
  appId: "1:403111331493:web:9491c7c1d05a20a2d3ef4c",
  measurementId: "G-R32G6FGTME"
};

// Log environment variables for debugging
console.log('Firebase Config:', {
  apiKey: firebaseConfig.apiKey ? 'PRESENT' : 'MISSING',
  authDomain: firebaseConfig.authDomain ? 'PRESENT' : 'MISSING',
  projectId: firebaseConfig.projectId ? 'PRESENT' : 'MISSING'
});

// Firebase application and service instances
let app;
let auth;
let db;

/**
 * Initializes Firebase services
 * 
 * @description
 * - Checks if Firebase is already initialized
 * - Prevents multiple initializations
 * - Sets up authentication and Firestore
 * 
 * @returns {Object} Firebase app, auth, and db instances
 * @throws {Error} If Firebase initialization fails
 */
export const initializeFirebase = () => {
  try {
    // Prevent multiple Firebase app initializations
    if (!getApps().length) {
      app = initializeApp(firebaseConfig);
      auth = getAuth(app);
      db = getFirestore(app);
    }

    return { app, auth, db };
  } catch (error) {
    console.error('Firebase initialization error:', error);
    throw error;
  }
};

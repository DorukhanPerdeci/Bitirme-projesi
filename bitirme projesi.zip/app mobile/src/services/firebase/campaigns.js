import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit,
  startAfter,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './config';

// Campaigns collection reference
const campaignsCollection = collection(db, 'campaigns');

/**
 * Retrieves all campaigns
 * @param {number} limitCount - Pagination limit
 * @param {Object} lastDoc - Last document (for pagination)
 * @returns {Promise} - Campaign list
 */
export const getAllCampaigns = async (limitCount = 10, lastDoc = null) => {
  try {
    let campaignsQuery;
    
    if (lastDoc) {
      campaignsQuery = query(
        campaignsCollection,
        orderBy('created_at', 'desc'),
        startAfter(lastDoc),
        limit(limitCount)
      );
    } else {
      campaignsQuery = query(
        campaignsCollection,
        orderBy('created_at', 'desc'),
        limit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(campaignsQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    const lastVisible = querySnapshot.docs[querySnapshot.docs.length - 1];
    
    return { 
      campaigns, 
      lastDoc: lastVisible, 
      error: null 
    };
  } catch (error) {
    console.error('Error retrieving campaigns:', error);
    return { campaigns: [], lastDoc: null, error: error.message };
  }
};

/**
 * Retrieves popular campaigns
 * @param {number} limitCount - Pagination limit
 * @returns {Promise} - Popular campaign list
 */
export const getPopularCampaigns = async (limitCount = 5) => {
  try {
    const popularQuery = query(
      campaignsCollection,
      where('is_popular', '==', true),
      orderBy('created_at', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(popularQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { campaigns, error: null };
  } catch (error) {
    console.error('Error retrieving popular campaigns:', error);
    return { campaigns: [], error: error.message };
  }
};

/**
 * Retrieves new campaigns
 * @param {number} limitCount - Pagination limit
 * @returns {Promise} - New campaign list
 */
export const getNewCampaigns = async (limitCount = 5) => {
  try {
    const newQuery = query(
      campaignsCollection,
      where('is_new', '==', true),
      orderBy('created_at', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(newQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { campaigns, error: null };
  } catch (error) {
    console.error('Error retrieving new campaigns:', error);
    return { campaigns: [], error: error.message };
  }
};

/**
 * Retrieves campaigns by category
 * @param {string} category - Category name
 * @param {number} limitCount - Pagination limit
 * @param {Object} lastDoc - Last document (for pagination)
 * @returns {Promise} - Category campaign list
 */
export const getCampaignsByCategory = async (category, limitCount = 10, lastDoc = null) => {
  try {
    let categoryQuery;
    
    if (lastDoc) {
      categoryQuery = query(
        campaignsCollection,
        where('category', '==', category),
        orderBy('created_at', 'desc'),
        startAfter(lastDoc),
        limit(limitCount)
      );
    } else {
      categoryQuery = query(
        campaignsCollection,
        where('category', '==', category),
        orderBy('created_at', 'desc'),
        limit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(categoryQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    const lastVisible = querySnapshot.docs[querySnapshot.docs.length - 1];
    
    return { 
      campaigns, 
      lastDoc: lastVisible, 
      error: null 
    };
  } catch (error) {
    console.error('Error retrieving category campaigns:', error);
    return { campaigns: [], lastDoc: null, error: error.message };
  }
};

/**
 * Retrieves campaign details
 * @param {string} campaignId - Campaign ID
 * @returns {Promise} - Campaign details
 */
export const getCampaignDetails = async (campaignId) => {
  try {
    const campaignRef = doc(campaignsCollection, campaignId);
    const campaignSnap = await getDoc(campaignRef);
    
    if (campaignSnap.exists()) {
      return { 
        campaign: {
          id: campaignSnap.id,
          ...campaignSnap.data()
        }, 
        error: null 
      };
    } else {
      return { campaign: null, error: 'Campaign not found' };
    }
  } catch (error) {
    console.error('Error retrieving campaign details:', error);
    return { campaign: null, error: error.message };
  }
};

/**
 * Retrieves similar campaigns
 * @param {string} campaignId - Current campaign ID
 * @param {string} category - Campaign category
 * @param {number} limitCount - Pagination limit
 * @returns {Promise} - Similar campaign list
 */
export const getSimilarCampaigns = async (campaignId, category, limitCount = 3) => {
  try {
    const similarQuery = query(
      campaignsCollection,
      where('category', '==', category),
      where('__name__', '!=', campaignId),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(similarQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { campaigns, error: null };
  } catch (error) {
    console.error('Error retrieving similar campaigns:', error);
    return { campaigns: [], error: error.message };
  }
};

/**
 * Campaign search
 * @param {string} searchQuery - Search text
 * @returns {Promise} - Search results
 */
export const searchCampaigns = async (searchQuery) => {
  try {
    // Note: Firestore does not support full-text search
    // so we're doing a simple search. For more advanced
    // search functionality, consider using a service like Algolia.
    const querySnapshot = await getDocs(campaignsCollection);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      const searchableText = `${data.title} ${data.description} ${data.brand}`.toLowerCase();
      
      if (searchableText.includes(searchQuery.toLowerCase())) {
        campaigns.push({
          id: doc.id,
          ...data
        });
      }
    });
    
    return { campaigns, error: null };
  } catch (error) {
    console.error('Error searching campaigns:', error);
    return { campaigns: [], error: error.message };
  }
};

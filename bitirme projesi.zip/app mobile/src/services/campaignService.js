/**
 * Service for campaign operations
 */

import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit as firestoreLimit,
  startAfter,
  serverTimestamp,
  updateDoc,
  addDoc,
  deleteDoc,
  arrayUnion,
  arrayRemove,
  increment
} from 'firebase/firestore';
import { db, auth } from './firebase/config';

// Collection references
const campaignsCollection = collection(db, 'campaigns');
const categoriesCollection = collection(db, 'categories');
const influencersCollection = collection(db, 'influencers');

/**
 * Retrieves campaigns
 * @param {object} params - Filtering parameters
 * @returns {Promise<object>} Campaign list and pagination information
 */
export const getCampaigns = async (params = {}) => {
  try {
    const { page = 1, limit = 10, category, search, sort } = params;
    const limitCount = parseInt(limit);
    let lastDoc = null;
    
    // Determine last document for pagination
    if (page > 1) {
      const previousPageQuery = query(
        campaignsCollection,
        orderBy('created_at', 'desc'),
        firestoreLimit((page - 1) * limitCount)
      );
      
      const previousPageSnapshot = await getDocs(previousPageQuery);
      const docs = previousPageSnapshot.docs;
      
      if (docs.length > 0) {
        lastDoc = docs[docs.length - 1];
      }
    }
    
    let campaignsQuery = query(
      campaignsCollection,
      orderBy('created_at', 'desc'),
      firestoreLimit(limitCount)
    );
    
    // Category filter
    if (category) {
      campaignsQuery = query(
        campaignsCollection,
        where('categories', 'array-contains', category),
        orderBy('created_at', 'desc'),
        firestoreLimit(limitCount)
      );
    }
    
    // Search filter
    if (search) {
      campaignsQuery = query(
        campaignsCollection,
        where('title', '>=', search),
        where('title', '<=', search + '\uf8ff'),
        orderBy('title'),
        firestoreLimit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(campaignsQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        title: doc.data().title,
        description: doc.data().description,
        image: doc.data().image_url,
        categories: doc.data().categories,
        influencer: doc.data().influencer_id,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });
    
    // Find total number of campaigns
    const totalQuery = query(campaignsCollection);
    const totalSnapshot = await getDocs(totalQuery);
    const total = totalSnapshot.size;
    
    return {
      data: campaigns,
      pagination: {
        total,
        page,
        limit: limitCount,
        pages: Math.ceil(total / limitCount),
      },
    };
  } catch (error) {
    console.error('Error retrieving campaigns:', error);
    throw error;
  }
};

/**
 * Retrieves campaign details
 * @param {string} id - Campaign ID
 * @returns {Promise<object>} Campaign details
 */
export const getCampaignDetails = async (id) => {
  try {
    const campaignRef = doc(db, 'campaigns', id);
    const campaignSnap = await getDoc(campaignRef);
    
    if (!campaignSnap.exists()) {
      throw new Error('Campaign not found');
    }
    
    const campaignData = campaignSnap.data();
    
    // Retrieve related influencer information
    const influencerRef = doc(db, 'influencers', campaignData.influencer_id);
    const influencerSnap = await getDoc(influencerRef);
    const influencerData = influencerSnap.exists() ? influencerSnap.data() : null;
    
    return {
      id: campaignSnap.id,
      ...campaignData,
      // Fields compatible with API
      title: campaignData.title,
      description: campaignData.description,
      image: campaignData.image_url,
      categories: campaignData.categories,
      createdAt: campaignData.created_at?.toDate() || new Date(),
      influencer: influencerData ? {
        id: influencerSnap.id,
        name: influencerData.name,
        username: influencerData.username,
        avatar: influencerData.avatar_url,
      } : null
    };
  } catch (error) {
    console.error('Error retrieving campaign details:', error);
    throw error;
  }
};

/**
 * Retrieves popular campaigns
 * @param {number} limit - Limit
 * @returns {Promise<Array>} Campaign list
 */
export const getPopularCampaigns = async (limit = 5) => {
  try {
    const limitCount = parseInt(limit);
    
    const popularQuery = query(
      campaignsCollection,
      orderBy('likes_count', 'desc'),
      firestoreLimit(limitCount)
    );
    
    const querySnapshot = await getDocs(popularQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        title: doc.data().title,
        description: doc.data().description,
        image: doc.data().image_url,
        categories: doc.data().categories,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });
    
    return campaigns;
  } catch (error) {
    console.error('Error retrieving popular campaigns:', error);
    throw error;
  }
};

/**
 * Retrieves campaigns by category
 * @param {string} categoryId - Category ID
 * @param {object} params - Filtering parameters
 * @returns {Promise<object>} Campaign list
 */
export const getCampaignsByCategory = async (categoryId, params = {}) => {
  try {
    const { page = 1, limit = 10 } = params;
    const limitCount = parseInt(limit);
    
    const campaignsQuery = query(
      campaignsCollection,
      where('categories', 'array-contains', categoryId),
      orderBy('created_at', 'desc'),
      firestoreLimit(limitCount)
    );
    
    const querySnapshot = await getDocs(campaignsQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        title: doc.data().title,
        description: doc.data().description,
        image: doc.data().image_url,
        categories: doc.data().categories,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });
    
    // Find total number of campaigns
    const totalQuery = query(
      campaignsCollection, 
      where('categories', 'array-contains', categoryId)
    );
    const totalSnapshot = await getDocs(totalQuery);
    const total = totalSnapshot.size;
    
    return {
      data: campaigns,
      pagination: {
        total,
        page,
        limit: limitCount,
        pages: Math.ceil(total / limitCount),
      },
    };
  } catch (error) {
    console.error('Error retrieving campaigns by category:', error);
    throw error;
  }
};

/**
 * Joins a campaign
 * @param {string} campaignId - Campaign ID
 * @returns {Promise<object>} Operation result
 */
export const joinCampaign = async (campaignId) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const campaignRef = doc(db, 'campaigns', campaignId);
    const userRef = doc(db, 'users', currentUser.uid);

    // Add campaign to user's joined campaigns
    await updateDoc(userRef, {
      joined_campaigns: arrayUnion(campaignId),
      updated_at: serverTimestamp()
    });

    // Update campaign's participant count
    await updateDoc(campaignRef, {
      participant_count: increment(1),
      updated_at: serverTimestamp()
    });

    return { 
      success: true, 
      message: 'Joined campaign' 
    };
  } catch (error) {
    console.error('Error joining campaign:', error);
    throw error;
  }
};

/**
 * Leaves a campaign
 * @param {string} campaignId - Campaign ID
 * @returns {Promise<object>} Operation result
 */
export const leaveCampaign = async (campaignId) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const campaignRef = doc(db, 'campaigns', campaignId);
    const userRef = doc(db, 'users', currentUser.uid);

    // Remove campaign from user's joined campaigns
    await updateDoc(userRef, {
      joined_campaigns: arrayRemove(campaignId),
      updated_at: serverTimestamp()
    });

    // Update campaign's participant count
    await updateDoc(campaignRef, {
      participant_count: increment(-1),
      updated_at: serverTimestamp()
    });

    return { 
      success: true, 
      message: 'Left campaign' 
    };
  } catch (error) {
    console.error('Error leaving campaign:', error);
    throw error;
  }
};

/**
 * Centralized service exports for Slash App
 */

// Firebase Authentication Services
export { 
  signUp, 
  signIn, 
  signInWithGoogle, 
  signInWithFacebook, 
  logout, 
  resetPassword,
  updateUserProfile,
  changePassword
} from './authService';

// Campaign Services
export { 
  getCampaigns, 
  getCampaignDetails, 
  getPopularCampaigns,
  getCampaignsByCategory,
  joinCampaign,
  leaveCampaign
} from './campaignService';

// Influencer Services
export { 
  getInfluencers, 
  getInfluencerDetails, 
  getPopularInfluencers, 
  getInfluencerCategories,
  followInfluencer,
  unfollowInfluencer,
  getInfluencerCampaigns
} from './influencerService';

// Notification Services
export { 
  getNotifications, 
  markAsRead, 
  markAllAsRead,
  deleteNotification,
  deleteAllNotifications
} from './notificationService';

// Firebase Utility Hooks
import { useState } from 'react';

/**
 * Custom hook for managing async Firebase operations
 * @param {Function} asyncFunction - Async Firebase service function
 * @returns {Object} State and methods for managing async operation
 */
export const useFirebaseOperation = (asyncFunction) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const execute = async (...args) => {
    setLoading(true);
    setError(null);

    try {
      const result = await asyncFunction(...args);
      setData(result);
      return result;
    } catch (err) {
      setError(err);
      console.error('Firebase Operation Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setData(null);
    setError(null);
    setLoading(false);
  };

  return {
    data,
    loading,
    error,
    execute,
    reset
  };
};

// Firebase Operation Status Constants
export const OPERATION_STATUS = {
  IDLE: 'idle',
  LOADING: 'loading',
  SUCCESS: 'success',
  ERROR: 'error'
};

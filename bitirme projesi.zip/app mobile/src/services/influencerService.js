/**
 * Service for influencer operations
 */

import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit as firestoreLimit,
  startAfter,
  serverTimestamp,
  updateDoc,
  addDoc,
  deleteDoc,
  arrayUnion,
  arrayRemove,
  increment
} from 'firebase/firestore';
import { db, auth } from './firebase/config';

// Influencer collection reference
const influencersCollection = collection(db, 'influencers');
const campaignsCollection = collection(db, 'campaigns');
const usersCollection = collection(db, 'users');

/**
 * Retrieves all influencers
 * @param {object} params - Filtering parameters
 * @returns {Promise<object>} Influencer list and pagination information
 */
export const getInfluencers = async (params = {}) => {
  try {
    const { page = 1, limit = 10, category, search, sort } = params;
    const limitCount = parseInt(limit);
    let lastDoc = null;
    
    // Determine last document for pagination
    if (page > 1) {
      // Find last document of previous page
      const previousPageQuery = query(
        influencersCollection,
        orderBy('created_at', 'desc'),
        firestoreLimit((page - 1) * limitCount)
      );
      
      const previousPageSnapshot = await getDocs(previousPageQuery);
      const docs = previousPageSnapshot.docs;
      
      if (docs.length > 0) {
        lastDoc = docs[docs.length - 1];
      }
    }
    
    let influencersQuery;
    
    if (lastDoc) {
      influencersQuery = query(
        influencersCollection,
        orderBy('created_at', 'desc'),
        startAfter(lastDoc),
        firestoreLimit(limitCount)
      );
    } else {
      influencersQuery = query(
        influencersCollection,
        orderBy('created_at', 'desc'),
        firestoreLimit(limitCount)
      );
    }
    
    // Add category filter
    if (category) {
      influencersQuery = query(
        influencersCollection,
        where('categories', 'array-contains', category),
        orderBy('created_at', 'desc'),
        lastDoc ? startAfter(lastDoc) : null,
        firestoreLimit(limitCount)
      );
    }
    
    const querySnapshot = await getDocs(influencersQuery);
    const influencers = [];
    
    querySnapshot.forEach((doc) => {
      influencers.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        name: doc.data().name,
        username: doc.data().username,
        avatar: doc.data().avatar_url,
        bio: doc.data().bio,
        categories: doc.data().categories,
        socialLinks: doc.data().social_links,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });
    
    // Find total number of influencers
    const totalQuery = query(influencersCollection);
    const totalSnapshot = await getDocs(totalQuery);
    const total = totalSnapshot.size;
    
    return {
      data: influencers,
      pagination: {
        total,
        page,
        limit: limitCount,
        pages: Math.ceil(total / limitCount),
      },
    };
  } catch (error) {
    console.error('Error retrieving influencers:', error);
    throw error;
  }
};

/**
 * Retrieves popular influencers
 * @param {number} limit - Limit
 * @returns {Promise<Array>} Influencer list
 */
export const getPopularInfluencers = async (limit = 5) => {
  try {
    const limitCount = parseInt(limit);
    
    // Sort popular influencers by follower count
    const popularQuery = query(
      influencersCollection,
      orderBy('followers_count', 'desc'),
      firestoreLimit(limitCount)
    );
    
    const querySnapshot = await getDocs(popularQuery);
    const influencers = [];
    
    querySnapshot.forEach((doc) => {
      influencers.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        name: doc.data().name,
        username: doc.data().username,
        avatar: doc.data().avatar_url,
        bio: doc.data().bio,
        categories: doc.data().categories,
        socialLinks: doc.data().social_links,
        createdAt: doc.data().created_at?.toDate() || new Date(),
        followers: doc.data().followers_count || 0,
      });
    });
    
    return influencers;
  } catch (error) {
    console.error('Error retrieving popular influencers:', error);
    throw error;
  }
};

/**
 * Retrieves influencer details
 * @param {string} id - Influencer ID
 * @returns {Promise<object>} Influencer details
 */
export const getInfluencerDetails = async (id) => {
  try {
    const influencerRef = doc(db, 'influencers', id);
    const influencerSnap = await getDoc(influencerRef);
    
    if (!influencerSnap.exists()) {
      throw new Error('Influencer not found');
    }
    
    const influencerData = influencerSnap.data();
    
    // Retrieve related campaigns
    const relatedCampaigns = await getRelatedCampaigns(influencerData.categories[0], 3);
    
    return {
      id: influencerSnap.id,
      ...influencerData,
      // Fields compatible with API
      name: influencerData.name,
      username: influencerData.username,
      avatar: influencerData.avatar_url,
      bio: influencerData.bio,
      categories: influencerData.categories,
      socialLinks: influencerData.social_links,
      createdAt: influencerData.created_at?.toDate() || new Date(),
      relatedCampaigns
    };
  } catch (error) {
    console.error('Error retrieving influencer details:', error);
    throw error;
  }
};

/**
 * Retrieves related campaigns
 * @param {string} category - Category
 * @param {number} limit - Limit
 * @returns {Promise<Array>} Related campaigns
 */
const getRelatedCampaigns = async (category, limit = 3) => {
  try {
    const relatedCampaignsQuery = query(
      campaignsCollection,
      where('categories', 'array-contains', category),
      orderBy('created_at', 'desc'),
      firestoreLimit(limit)
    );
    
    const querySnapshot = await getDocs(relatedCampaignsQuery);
    const campaigns = [];
    
    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        name: doc.data().name,
        description: doc.data().description,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });
    
    return campaigns;
  } catch (error) {
    console.error('Error retrieving related campaigns:', error);
    throw error;
  }
};

/**
 * Retrieves influencer categories
 * @returns {Promise<Array>} Category list
 */
export const getInfluencerCategories = async () => {
  try {
    const categoriesCollection = collection(db, 'influencerCategories');
    const querySnapshot = await getDocs(categoriesCollection);
    
    const categories = [];
    querySnapshot.forEach((doc) => {
      categories.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        name: doc.data().name,
        icon: doc.data().icon
      });
    });
    
    return categories;
  } catch (error) {
    console.error('Error retrieving influencer categories:', error);
    throw error;
  }
};

/**
 * Follows an influencer
 * @param {string} influencerId - Influencer ID
 * @returns {Promise<object>} Operation result
 */
export const followInfluencer = async (influencerId) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const influencerRef = doc(db, 'influencers', influencerId);
    const userRef = doc(db, 'users', currentUser.uid);

    // Add influencer to user's follow list
    await updateDoc(userRef, {
      followedInfluencers: arrayUnion(influencerId),
      updatedAt: serverTimestamp()
    });

    // Update influencer's follower count
    await updateDoc(influencerRef, {
      followersCount: increment(1),
      updatedAt: serverTimestamp()
    });

    return { 
      success: true, 
      message: 'Influencer followed' 
    };
  } catch (error) {
    console.error('Error following influencer:', error);
    throw error;
  }
};

/**
 * Unfollows an influencer
 * @param {string} influencerId - Influencer ID
 * @returns {Promise<object>} Operation result
 */
export const unfollowInfluencer = async (influencerId) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User not logged in');
    }

    const influencerRef = doc(db, 'influencers', influencerId);
    const userRef = doc(db, 'users', currentUser.uid);

    // Remove influencer from user's follow list
    await updateDoc(userRef, {
      followedInfluencers: arrayRemove(influencerId),
      updatedAt: serverTimestamp()
    });

    // Update influencer's follower count
    await updateDoc(influencerRef, {
      followersCount: increment(-1),
      updatedAt: serverTimestamp()
    });

    return { 
      success: true, 
      message: 'Influencer unfollowed' 
    };
  } catch (error) {
    console.error('Error unfollowing influencer:', error);
    throw error;
  }
};

/**
 * Retrieves influencer campaigns
 * @param {string} influencerId - Influencer ID
 * @param {object} params - Filtering parameters
 * @returns {Promise<object>} Campaign list
 */
export const getInfluencerCampaigns = async (influencerId, params = {}) => {
  try {
    const { page = 1, limit = 10 } = params;
    const limitCount = parseInt(limit);

    const influencerRef = doc(db, 'influencers', influencerId);
    const influencerSnap = await getDoc(influencerRef);

    if (!influencerSnap.exists()) {
      throw new Error('Influencer not found');
    }

    const campaignsQuery = query(
      campaignsCollection,
      where('influencerId', '==', influencerId),
      orderBy('created_at', 'desc'),
      firestoreLimit(limitCount)
    );

    const querySnapshot = await getDocs(campaignsQuery);
    const campaigns = [];

    querySnapshot.forEach((doc) => {
      campaigns.push({
        id: doc.id,
        ...doc.data(),
        // Fields compatible with API
        name: doc.data().name,
        description: doc.data().description,
        createdAt: doc.data().created_at?.toDate() || new Date(),
      });
    });

    // Find total number of campaigns
    const totalQuery = query(
      campaignsCollection, 
      where('influencerId', '==', influencerId)
    );
    const totalSnapshot = await getDocs(totalQuery);
    const total = totalSnapshot.size;

    return {
      data: campaigns,
      pagination: {
        total,
        page,
        limit: limitCount,
        pages: Math.ceil(total / limitCount),
      },
    };
  } catch (error) {
    console.error('Error retrieving influencer campaigns:', error);
    throw error;
  }
};

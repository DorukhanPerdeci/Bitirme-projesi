/**
 * Authentication and user management service
 */

import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail,
  signInWithPopup,
  GoogleAuthProvider,
  FacebookAuthProvider,
  updateProfile,
  updateEmail,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp,
  collection
} from 'firebase/firestore';
import { auth, db } from './firebase/config';

const usersCollection = collection(db, 'users');

/**
 * Sign up with email and password
 * @param {object} userData - User registration details
 * @returns {Promise<object>} Registration result
 */
export const signUp = async (userData) => {
  try {
    const { email, password, name, username } = userData;

    // Create user with Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Update user profile
    await updateProfile(user, {
      displayName: name
    });

    // Create user document in Firestore
    const userDocRef = doc(db, 'users', user.uid);
    await setDoc(userDocRef, {
      name: name,
      username: username || user.displayName,
      email: user.email,
      profile_image: user.photoURL || null,
      role: 'user', // Default role
      created_at: serverTimestamp(),
      updated_at: serverTimestamp(),
      account_status: 'active'
    });

    return {
      success: true,
      message: 'Registration successful',
      user: {
        id: user.uid,
        name: user.displayName,
        email: user.email
      }
    };
  } catch (error) {
    console.error('Registration error:', error);
    throw error;
  }
};

/**
 * Sign in with email and password
 * @param {string} email - Email address
 * @param {string} password - Password
 * @returns {Promise<object>} Sign in result
 */
export const signIn = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Fetch user document
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);

    return {
      success: true,
      message: 'Sign in successful',
      user: {
        id: user.uid,
        name: user.displayName,
        email: user.email,
        username: userDoc.data()?.username,
        role: userDoc.data()?.role
      }
    };
  } catch (error) {
    console.error('Sign in error:', error);
    throw error;
  }
};

/**
 * Sign in with Google
 * @returns {Promise<object>} Sign in result
 */
export const signInWithGoogle = async () => {
  try {
    const provider = new GoogleAuthProvider();
    const userCredential = await signInWithPopup(auth, provider);
    const user = userCredential.user;

    // Check and create user document in Firestore
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
      await setDoc(userDocRef, {
        name: user.displayName,
        username: user.displayName,
        email: user.email,
        profile_image: user.photoURL,
        role: 'user',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
        account_status: 'active',
        google_account: true
      });
    }

    return {
      success: true,
      message: 'Google sign in successful',
      user: {
        id: user.uid,
        name: user.displayName,
        email: user.email,
        avatar: user.photoURL
      }
    };
  } catch (error) {
    console.error('Google sign in error:', error);
    throw error;
  }
};

/**
 * Sign in with Facebook
 * @returns {Promise<object>} Sign in result
 */
export const signInWithFacebook = async () => {
  try {
    const provider = new FacebookAuthProvider();
    const userCredential = await signInWithPopup(auth, provider);
    const user = userCredential.user;

    // Check and create user document in Firestore
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
      await setDoc(userDocRef, {
        name: user.displayName,
        username: user.displayName,
        email: user.email,
        profile_image: user.photoURL,
        role: 'user',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
        account_status: 'active',
        facebook_account: true
      });
    }

    return {
      success: true,
      message: 'Facebook sign in successful',
      user: {
        id: user.uid,
        name: user.displayName,
        email: user.email,
        avatar: user.photoURL
      }
    };
  } catch (error) {
    console.error('Facebook sign in error:', error);
    throw error;
  }
};

/**
 * Log out
 * @returns {Promise<object>} Logout result
 */
export const logout = async () => {
  try {
    await signOut(auth);
    return {
      success: true,
      message: 'Logout successful'
    };
  } catch (error) {
    console.error('Logout error:', error);
    throw error;
  }
};

/**
 * Send password reset email
 * @param {string} email - Email address
 * @returns {Promise<object>} Password reset result
 */
export const resetPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return {
      success: true,
      message: 'Password reset email sent'
    };
  } catch (error) {
    console.error('Password reset error:', error);
    throw error;
  }
};

/**
 * Update user profile
 * @param {object} profileData - Profile data to update
 * @returns {Promise<object>} Update result
 */
export const updateUserProfile = async (profileData) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User is not signed in');
    }

    const { name, username, email, avatar } = profileData;

    // Update Firebase Authentication profile
    if (name) {
      await updateProfile(currentUser, {
        displayName: name
      });
    }

    // Update email
    if (email && email !== currentUser.email) {
      await updateEmail(currentUser, email);
    }

    // Update user document in Firestore
    const userDocRef = doc(db, 'users', currentUser.uid);
    await updateDoc(userDocRef, {
      name: name || currentUser.displayName,
      username: username || currentUser.displayName,
      email: email || currentUser.email,
      profile_image: avatar || currentUser.photoURL,
      updated_at: serverTimestamp()
    });

    return {
      success: true,
      message: 'Profile updated',
      user: {
        id: currentUser.uid,
        name: name || currentUser.displayName,
        email: email || currentUser.email,
        avatar: avatar || currentUser.photoURL
      }
    };
  } catch (error) {
    console.error('Profile update error:', error);
    throw error;
  }
};

/**
 * Change password
 * @param {string} currentPassword - Current password
 * @param {string} newPassword - New password
 * @returns {Promise<object>} Password change result
 */
export const changePassword = async (currentPassword, newPassword) => {
  try {
    const currentUser = auth.currentUser;

    if (!currentUser) {
      throw new Error('User is not signed in');
    }

    // Re-authenticate with current credentials
    const credential = EmailAuthProvider.credential(currentUser.email, currentPassword);
    await reauthenticateWithCredential(currentUser, credential);

    // Update password
    await updatePassword(currentUser, newPassword);

    return {
      success: true,
      message: 'Password changed successfully'
    };
  } catch (error) {
    console.error('Password change error:', error);
    throw error;
  }
};

/**
 * Yardımcı fonksiyonlar için ana dışa aktarma dosyası
 */

// Tüm yardımcı modülleri dışa aktar
export * from './dateUtils';
export * from './formatUtils';
export * from './validationUtils';
export * from './storageUtils';

/**
 * Rastgele bir ID oluşturur
 * @returns {string} Rastgele ID
 */
export const generateId = () => {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

/**
 * İki nesneyi derin birleştirir
 * @param {object} target - Hedef nesne
 * @param {object} source - Kaynak nesne
 * @returns {object} Birleştirilmiş nesne
 */
export const deepMerge = (target, source) => {
  const output = { ...target };
  
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) {
          Object.assign(output, { [key]: source[key] });
        } else {
          output[key] = deepMerge(target[key], source[key]);
        }
      } else {
        Object.assign(output, { [key]: source[key] });
      }
    });
  }
  
  return output;
};

/**
 * Değerin bir nesne olup olmadığını kontrol eder
 * @param {any} item - Kontrol edilecek değer
 * @returns {boolean} Nesne ise true, değilse false
 */
const isObject = (item) => {
  return (item && typeof item === 'object' && !Array.isArray(item));
};

/**
 * Bir diziyi karıştırır (rastgele sıralar)
 * @param {Array} array - Karıştırılacak dizi
 * @returns {Array} Karıştırılmış dizi
 */
export const shuffleArray = (array) => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

/**
 * Bir dizideki benzersiz değerleri döndürür
 * @param {Array} array - İşlenecek dizi
 * @param {string} key - Nesne dizileri için benzersizlik anahtarı
 * @returns {Array} Benzersiz değerler dizisi
 */
export const uniqueArray = (array, key) => {
  if (!array || array.length === 0) return [];
  
  if (key) {
    const seen = new Set();
    return array.filter(item => {
      const value = item[key];
      if (seen.has(value)) {
        return false;
      }
      seen.add(value);
      return true;
    });
  }
  
  return [...new Set(array)];
};

/**
 * Bir diziyi belirli bir özelliğe göre gruplar
 * @param {Array} array - Gruplanacak dizi
 * @param {string} key - Gruplama anahtarı
 * @returns {object} Gruplanmış nesne
 */
export const groupBy = (array, key) => {
  return array.reduce((result, item) => {
    const groupKey = item[key];
    if (!result[groupKey]) {
      result[groupKey] = [];
    }
    result[groupKey].push(item);
    return result;
  }, {});
};

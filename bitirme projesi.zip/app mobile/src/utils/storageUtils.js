/**
 * AsyncStorage işlemleri için yardımcı fonksiyonlar
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Veriyi AsyncStorage'a kaydeder
 * @param {string} key - Veri anahtarı
 * @param {any} value - Kaydedilecek veri
 * @returns {Promise<void>}
 */
export const storeData = async (key, value) => {
  try {
    const jsonValue = typeof value === 'string' ? value : JSON.stringify(value);
    await AsyncStorage.setItem(key, jsonValue);
    return true;
  } catch (error) {
    console.error('Veri kaydetme hatası:', error);
    return false;
  }
};

/**
 * AsyncStorage'dan veri okur
 * @param {string} key - Veri anahtarı
 * @returns {Promise<any>} Okunan veri
 */
export const getData = async (key) => {
  try {
    const jsonValue = await AsyncStorage.getItem(key);
    return jsonValue != null ? JSON.parse(jsonValue) : null;
  } catch (error) {
    console.error('Veri okuma hatası:', error);
    return null;
  }
};

/**
 * AsyncStorage'dan veriyi siler
 * @param {string} key - Silinecek veri anahtarı
 * @returns {Promise<boolean>} İşlem başarılı ise true, değilse false
 */
export const removeData = async (key) => {
  try {
    await AsyncStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error('Veri silme hatası:', error);
    return false;
  }
};

/**
 * AsyncStorage'daki tüm verileri temizler
 * @returns {Promise<boolean>} İşlem başarılı ise true, değilse false
 */
export const clearAll = async () => {
  try {
    await AsyncStorage.clear();
    return true;
  } catch (error) {
    console.error('Tüm verileri temizleme hatası:', error);
    return false;
  }
};

/**
 * AsyncStorage'daki tüm anahtarları getirir
 * @returns {Promise<string[]>} Anahtar listesi
 */
export const getAllKeys = async () => {
  try {
    return await AsyncStorage.getAllKeys();
  } catch (error) {
    console.error('Tüm anahtarları getirme hatası:', error);
    return [];
  }
};

/**
 * Kullanıcı oturum bilgilerini kaydeder
 * @param {object} userData - Kullanıcı bilgileri
 * @returns {Promise<boolean>} İşlem başarılı ise true, değilse false
 */
export const saveUserSession = async (userData) => {
  return await storeData('@user_session', userData);
};

/**
 * Kullanıcı oturum bilgilerini getirir
 * @returns {Promise<object|null>} Kullanıcı bilgileri
 */
export const getUserSession = async () => {
  return await getData('@user_session');
};

/**
 * Kullanıcı oturumunu sonlandırır
 * @returns {Promise<boolean>} İşlem başarılı ise true, değilse false
 */
export const clearUserSession = async () => {
  return await removeData('@user_session');
};

/**
 * Uygulama ayarlarını kaydeder
 * @param {object} settings - Ayarlar
 * @returns {Promise<boolean>} İşlem başarılı ise true, değilse false
 */
export const saveAppSettings = async (settings) => {
  return await storeData('@app_settings', settings);
};

/**
 * Uygulama ayarlarını getirir
 * @returns {Promise<object|null>} Ayarlar
 */
export const getAppSettings = async () => {
  return await getData('@app_settings');
};

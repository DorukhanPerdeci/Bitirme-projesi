/**
 * Biçimlendirme işlemleri için yardımcı fonksiyonlar
 */

/**
 * Fiyatı para birimi formatında biçimlendirir
 * @param {number} amount - Biçimlendirilecek miktar
 * @param {string} currency - Para birimi (varsayılan: 'TL')
 * @returns {string} Biçimlendirilmiş fiyat
 */
export const formatCurrency = (amount, currency = 'TL') => {
  if (amount === undefined || amount === null) return '';
  
  const formatter = new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: currency === 'TL' ? 'TRY' : currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  
  return formatter.format(amount);
};

/**
 * Sayıyı biçimlendirir (binlik ayırıcı ekler)
 * @param {number} number - Biçimlendirilecek sayı
 * @param {number} decimals - Ondalık basamak sayısı (varsayılan: 0)
 * @returns {string} Biçimlendirilmiş sayı
 */
export const formatNumber = (number, decimals = 0) => {
  if (number === undefined || number === null) return '';
  
  return number.toLocaleString('tr-TR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
};

/**
 * Metni belirli bir uzunlukta kısaltır
 * @param {string} text - Kısaltılacak metin
 * @param {number} maxLength - Maksimum uzunluk (varsayılan: 100)
 * @returns {string} Kısaltılmış metin
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text) return '';
  
  if (text.length <= maxLength) {
    return text;
  }
  
  return text.substring(0, maxLength) + '...';
};

/**
 * Telefon numarasını biçimlendirir
 * @param {string} phoneNumber - Biçimlendirilecek telefon numarası
 * @returns {string} Biçimlendirilmiş telefon numarası
 */
export const formatPhoneNumber = (phoneNumber) => {
  if (!phoneNumber) return '';
  
  // Sadece rakamları al
  const cleaned = phoneNumber.replace(/\D/g, '');
  
  // Türkiye telefon numarası formatı: +90 (5XX) XXX XX XX
  if (cleaned.length === 10) {
    return `+90 (${cleaned.substring(0, 3)}) ${cleaned.substring(3, 6)} ${cleaned.substring(6, 8)} ${cleaned.substring(8, 10)}`;
  } else if (cleaned.length === 11 && cleaned.startsWith('0')) {
    return `+90 (${cleaned.substring(1, 4)}) ${cleaned.substring(4, 7)} ${cleaned.substring(7, 9)} ${cleaned.substring(9, 11)}`;
  } else if (cleaned.length === 12 && cleaned.startsWith('90')) {
    return `+90 (${cleaned.substring(2, 5)}) ${cleaned.substring(5, 8)} ${cleaned.substring(8, 10)} ${cleaned.substring(10, 12)}`;
  }
  
  // Biçimlendirilemiyorsa olduğu gibi döndür
  return phoneNumber;
};

/**
 * Dosya boyutunu okunaklı hale getirir
 * @param {number} bytes - Bayt cinsinden dosya boyutu
 * @returns {string} Okunaklı dosya boyutu
 */
export const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

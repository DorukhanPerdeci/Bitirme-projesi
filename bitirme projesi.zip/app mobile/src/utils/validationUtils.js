/**
 * Doğrulama işlemleri için yardımcı fonksiyonlar
 */

/**
 * E-posta adresinin geçerli olup olmadığını kontrol eder
 * @param {string} email - Kontrol edilecek e-posta adresi
 * @returns {boolean} Geçerli ise true, değilse false
 */
export const isValidEmail = (email) => {
  if (!email) return false;
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Şifrenin belirli kriterlere uygun olup olmadığını kontrol eder
 * @param {string} password - Kontrol edilecek şifre
 * @param {object} options - Kontrol seçenekleri
 * @returns {boolean} Geçerli ise true, değilse false
 */
export const isValidPassword = (password, options = {}) => {
  if (!password) return false;
  
  const {
    minLength = 8,
    requireUppercase = true,
    requireLowercase = true,
    requireNumbers = true,
    requireSpecialChars = true,
  } = options;
  
  if (password.length < minLength) return false;
  
  if (requireUppercase && !/[A-Z]/.test(password)) return false;
  if (requireLowercase && !/[a-z]/.test(password)) return false;
  if (requireNumbers && !/[0-9]/.test(password)) return false;
  if (requireSpecialChars && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) return false;
  
  return true;
};

/**
 * Telefon numarasının geçerli olup olmadığını kontrol eder
 * @param {string} phoneNumber - Kontrol edilecek telefon numarası
 * @returns {boolean} Geçerli ise true, değilse false
 */
export const isValidPhoneNumber = (phoneNumber) => {
  if (!phoneNumber) return false;
  
  // Sadece rakamları al
  const cleaned = phoneNumber.replace(/\D/g, '');
  
  // Türkiye telefon numarası kontrolü
  if (cleaned.length === 10 && cleaned.startsWith('5')) {
    return true;
  } else if (cleaned.length === 11 && cleaned.startsWith('05')) {
    return true;
  } else if (cleaned.length === 12 && cleaned.startsWith('905')) {
    return true;
  } else if (cleaned.length === 13 && cleaned.startsWith('+905')) {
    return true;
  }
  
  return false;
};

/**
 * TC Kimlik numarasının geçerli olup olmadığını kontrol eder
 * @param {string} tcNumber - Kontrol edilecek TC Kimlik numarası
 * @returns {boolean} Geçerli ise true, değilse false
 */
export const isValidTCNumber = (tcNumber) => {
  if (!tcNumber || tcNumber.length !== 11) return false;
  
  // Sadece rakamlardan oluşmalı
  if (!/^\d{11}$/.test(tcNumber)) return false;
  
  // İlk rakam 0 olamaz
  if (tcNumber[0] === '0') return false;
  
  // Algoritma kontrolü
  let oddSum = 0;
  let evenSum = 0;
  let total = 0;
  
  for (let i = 0; i < 9; i++) {
    const digit = parseInt(tcNumber[i]);
    if (i % 2 === 0) {
      oddSum += digit;
    } else {
      evenSum += digit;
    }
    total += digit;
  }
  
  const tenthDigit = (oddSum * 7 - evenSum) % 10;
  if (parseInt(tcNumber[9]) !== tenthDigit) return false;
  
  total += parseInt(tcNumber[9]);
  const eleventhDigit = total % 10;
  if (parseInt(tcNumber[10]) !== eleventhDigit) return false;
  
  return true;
};

/**
 * Kredi kartı numarasının geçerli olup olmadığını kontrol eder (Luhn algoritması)
 * @param {string} cardNumber - Kontrol edilecek kredi kartı numarası
 * @returns {boolean} Geçerli ise true, değilse false
 */
export const isValidCreditCard = (cardNumber) => {
  if (!cardNumber) return false;
  
  // Sadece rakamları al
  const cleaned = cardNumber.replace(/\D/g, '');
  
  // Kredi kartı numarası 13-19 basamak olmalı
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Luhn algoritması
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
};

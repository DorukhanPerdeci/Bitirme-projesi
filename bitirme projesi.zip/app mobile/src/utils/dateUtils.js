/**
 * Tarih işlemleri için yardımcı fonksiyonlar
 */

/**
 * Verilen tarihi formatlar
 * @param {Date|string} date - Formatlanacak tarih
 * @param {string} format - Tarih formatı (varsayılan: 'DD.MM.YYYY')
 * @returns {string} Formatlanmış tarih
 */
export const formatDate = (date, format = 'DD.MM.YYYY') => {
  const d = typeof date === 'string' ? new Date(date) : date;
  
  if (!(d instanceof Date) || isNaN(d)) {
    return '';
  }
  
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  
  switch (format) {
    case 'DD.MM.YYYY':
      return `${day}.${month}.${year}`;
    case 'DD.MM.YYYY HH:MM':
      return `${day}.${month}.${year} ${hours}:${minutes}`;
    case 'HH:MM':
      return `${hours}:${minutes}`;
    case 'YYYY-MM-DD':
      return `${year}-${month}-${day}`;
    default:
      return `${day}.${month}.${year}`;
  }
};

/**
 * Verilen tarihin ne kadar zaman önce olduğunu döndürür
 * @param {Date|string} date - Tarih
 * @returns {string} Geçen süre metni
 */
export const timeAgo = (date) => {
  const d = typeof date === 'string' ? new Date(date) : date;
  
  if (!(d instanceof Date) || isNaN(d)) {
    return '';
  }
  
  const now = new Date();
  const seconds = Math.floor((now - d) / 1000);
  
  let interval = Math.floor(seconds / 31536000);
  if (interval >= 1) {
    return interval === 1 ? '1 yıl önce' : `${interval} yıl önce`;
  }
  
  interval = Math.floor(seconds / 2592000);
  if (interval >= 1) {
    return interval === 1 ? '1 ay önce' : `${interval} ay önce`;
  }
  
  interval = Math.floor(seconds / 86400);
  if (interval >= 1) {
    return interval === 1 ? '1 gün önce' : `${interval} gün önce`;
  }
  
  interval = Math.floor(seconds / 3600);
  if (interval >= 1) {
    return interval === 1 ? '1 saat önce' : `${interval} saat önce`;
  }
  
  interval = Math.floor(seconds / 60);
  if (interval >= 1) {
    return interval === 1 ? '1 dakika önce' : `${interval} dakika önce`;
  }
  
  return seconds < 10 ? 'şimdi' : `${Math.floor(seconds)} saniye önce`;
};

/**
 * İki tarih arasındaki farkı gün olarak hesaplar
 * @param {Date|string} startDate - Başlangıç tarihi
 * @param {Date|string} endDate - Bitiş tarihi
 * @returns {number} Gün farkı
 */
export const daysBetween = (startDate, endDate) => {
  const start = typeof startDate === 'string' ? new Date(startDate) : startDate;
  const end = typeof endDate === 'string' ? new Date(endDate) : endDate || new Date();
  
  if (!(start instanceof Date) || isNaN(start) || !(end instanceof Date) || isNaN(end)) {
    return 0;
  }
  
  const diffTime = Math.abs(end - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
};

/**
 * Tarihin geçerli olup olmadığını kontrol eder
 * @param {Date|string} date - Kontrol edilecek tarih
 * @returns {boolean} Geçerli ise true, değilse false
 */
export const isValidDate = (date) => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d instanceof Date && !isNaN(d);
};

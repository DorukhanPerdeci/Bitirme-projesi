export const campaigns = [
  {
    id: '1',
    title: 'Starbucks Yaz Kampanyası',
    description: 'İki soğuk içecek alana bir soğuk içecek bedava! Yazın keyfini Starbucks ile çıkarın.',
    brand: 'Starbucks',
    image: 'https://images.unsplash.com/photo-1589476993333-f55b84301219?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    endDate: '2025-08-31',
    isPopular: true,
    isNew: true,
    category: 'Yiyecek & İçecek',
    influencers: ['3', '5'],
    terms: 'Bu kampanya 31 Ağustos 2025 tarihine kadar geçerlidir. Kampanya tüm Starbucks şubelerinde geçerlidir. Kampanya diğer indirimlerle birleştirilemez.',
    howToUse: 'Kasada ödeme yaparken kampanyadan yararlanmak istediğinizi belirtin. Uygulama üzerinden QR kodu gösterin.'
  },
  {
    id: '2',
    title: 'Nike Koşu Ayakkabılarında %30 İndirim',
    description: 'Tüm Nike koşu ayakkabılarında geçerli %30 indirim fırsatını kaçırmayın!',
    brand: 'Nike',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    endDate: '2025-07-15',
    isPopular: true,
    isNew: false,
    category: 'Spor & Outdoor',
    influencers: ['1', '4'],
    terms: 'Bu kampanya 15 Temmuz 2025 tarihine kadar geçerlidir. Kampanya tüm Nike mağazalarında ve çevrimiçi mağazada geçerlidir. Outlet ürünleri kampanya kapsamı dışındadır.',
    howToUse: 'Mağazada ödeme yaparken kampanyadan yararlanmak istediğinizi belirtin. Online alışverişlerde sepette "KOSU30" kodunu kullanın.'
  },
  {
    id: '3',
    title: 'Sephora Yaz Güzellik Kutusu',
    description: '250 TL ve üzeri alışverişlerinizde yaz güzellik kutusunu hediye olarak alın!',
    brand: 'Sephora',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    endDate: '2025-06-30',
    isPopular: false,
    isNew: true,
    category: 'Güzellik & Bakım',
    influencers: ['2', '5'],
    terms: 'Bu kampanya 30 Haziran 2025 tarihine kadar geçerlidir. Kampanya tüm Sephora mağazalarında ve çevrimiçi mağazada geçerlidir. Stoklar tükenene kadar geçerlidir.',
    howToUse: 'Sepetinize 250 TL ve üzeri ürün ekleyin, güzellik kutusu otomatik olarak sepetinize eklenecektir.'
  },
  {
    id: '4',
    title: 'Yemeksepeti 50 TL İndirim',
    description: '100 TL ve üzeri siparişlerinizde geçerli 50 TL indirim kuponu!',
    brand: 'Yemeksepeti',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    endDate: '2025-05-31',
    isPopular: true,
    isNew: true,
    category: 'Yiyecek & İçecek',
    influencers: ['1', '3'],
    terms: 'Bu kampanya 31 Mayıs 2025 tarihine kadar geçerlidir. Kampanya 100 TL ve üzeri siparişlerde geçerlidir. Bir kullanıcı kampanyadan yalnızca bir kez yararlanabilir.',
    howToUse: 'Siparişinizi tamamlarken "YEMEK50" kodunu kullanın.'
  },
  {
    id: '5',
    title: 'Trendyol Süper İndirim Günleri',
    description: 'Seçili kategorilerde %70\'e varan indirimler!',
    brand: 'Trendyol',
    image: 'https://images.unsplash.com/photo-1607082350899-7e105aa886ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    endDate: '2025-06-15',
    isPopular: true,
    isNew: false,
    category: 'Alışveriş',
    influencers: ['2', '4', '5'],
    terms: 'Bu kampanya 15 Haziran 2025 tarihine kadar geçerlidir. İndirimler seçili ürünlerde geçerlidir. Stoklar tükenene kadar geçerlidir.',
    howToUse: 'Trendyol uygulaması veya web sitesinde "Süper İndirim" kategorisini ziyaret edin.'
  },
  {
    id: '6',
    title: 'Migros Hafta Sonu Fırsatları',
    description: 'Hafta sonu alışverişlerinizde Money kartınıza %15 para puan!',
    brand: 'Migros',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    endDate: '2025-07-31',
    isPopular: false,
    isNew: true,
    category: 'Market',
    influencers: ['3'],
    terms: 'Bu kampanya her hafta sonu 31 Temmuz 2025 tarihine kadar geçerlidir. Kampanya Money kart sahipleri için geçerlidir. Alkol ve tütün ürünleri kampanya kapsamı dışındadır.',
    howToUse: 'Kasada ödeme yaparken Money kartınızı gösterin.'
  }
];

export const influencers = [
  {
    id: '1',
    name: 'Ece Yılmaz',
    username: '@eceyilmaz',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    followers: 850000,
    category: 'Yaşam Tarzı',
    bio: 'Yaşam, moda ve seyahat tutkunu. Her gün yeni keşifler peşinde!'
  },
  {
    id: '2',
    name: 'Mert Kaya',
    username: '@mertkaya',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    followers: 1200000,
    category: 'Fitness',
    bio: 'Fitness eğitmeni ve beslenme uzmanı. Sağlıklı yaşam için ipuçları paylaşıyorum.'
  },
  {
    id: '3',
    name: 'Zeynep Demir',
    username: '@zeynepdemir',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    followers: 650000,
    category: 'Yemek',
    bio: 'Yemek bloggerı ve şef. Mutfakta yaratıcılık benim işim!'
  },
  {
    id: '4',
    name: 'Can Özkan',
    username: '@canozkan',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    followers: 920000,
    category: 'Teknoloji',
    bio: 'Teknoloji meraklısı ve yazılım geliştirici. En son teknoloji trendlerini paylaşıyorum.'
  },
  {
    id: '5',
    name: 'Ayşe Yıldız',
    username: '@ayseyildiz',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    followers: 1500000,
    category: 'Güzellik',
    bio: 'Makyaj sanatçısı ve güzellik uzmanı. Kendine güvenen kadınlar için içerikler üretiyorum.'
  }
];

export const notifications = [
  {
    id: '1',
    title: 'Yeni Kampanya',
    message: 'Starbucks\'ın yeni yaz kampanyasını keşfedin!',
    date: '2025-05-15T10:30:00',
    read: false,
    campaignId: '1'
  },
  {
    id: '2',
    title: 'Kampanya Bitiyor',
    message: 'Nike koşu ayakkabılarındaki indirim kampanyası yakında sona eriyor!',
    date: '2025-05-14T14:45:00',
    read: true,
    campaignId: '2'
  },
  {
    id: '3',
    title: 'Yeni Influencer',
    message: 'Zeynep Demir artık Slash\'ta! Hemen takip et ve kampanyalarını keşfet.',
    date: '2025-05-12T09:15:00',
    read: false,
    influencerId: '3'
  },
  {
    id: '4',
    title: 'Özel Teklif',
    message: 'Sadece sana özel: Yemeksepeti\'nde ekstra %10 indirim fırsatı!',
    date: '2025-05-10T18:20:00',
    read: true,
    campaignId: '4'
  },
  {
    id: '5',
    title: 'Hatırlatma',
    message: 'Kaydettiğin Sephora kampanyası 2 gün içinde sona eriyor!',
    date: '2025-05-08T11:05:00',
    read: false,
    campaignId: '3'
  }
];

export const categories = [
  {
    id: '1',
    name: 'Yiyecek & İçecek',
    icon: 'restaurant'
  },
  {
    id: '2',
    name: 'Moda',
    icon: 'shopping-bag'
  },
  {
    id: '3',
    name: 'Güzellik & Bakım',
    icon: 'spa'
  },
  {
    id: '4',
    name: 'Spor & Outdoor',
    icon: 'directions-run'
  },
  {
    id: '5',
    name: 'Elektronik',
    icon: 'devices'
  },
  {
    id: '6',
    name: 'Ev & Yaşam',
    icon: 'home'
  },
  {
    id: '7',
    name: 'Seyahat',
    icon: 'flight'
  },
  {
    id: '8',
    name: 'Market',
    icon: 'shopping-cart'
  }
];

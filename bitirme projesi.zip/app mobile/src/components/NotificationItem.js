import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform, Dimensions } from 'react-native';
import { Icon } from 'react-native-elements';
import { useRouter } from 'expo-router';
import { COLORS, FONTS, SIZES } from '../constants/theme';

const { width } = Dimensions.get('window');

const NotificationItem = ({ notification }) => {
  const router = useRouter();

  const handlePress = () => {
    if (notification.campaignId) {
      router.push(`/campaign/${notification.campaignId}`);
    } else if (notification.influencerId) {
      router.push(`/influencer/${notification.influencerId}`);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      const hours = date.getHours();
      const minutes = date.getMinutes();
      return `Bugün ${hours}:${minutes < 10 ? '0' + minutes : minutes}`;
    } else if (diffDays === 1) {
      return 'Dün';
    } else if (diffDays < 7) {
      return `${diffDays} gün önce`;
    } else {
      return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' });
    }
  };

  const getIcon = () => {
    if (notification.title.includes('Kampanya')) {
      return { name: 'local-offer', type: 'material', color: COLORS.primary };
    } else if (notification.title.includes('Influencer')) {
      return { name: 'person', type: 'material', color: COLORS.secondary };
    } else if (notification.title.includes('Teklif')) {
      return { name: 'gift', type: 'feather', color: COLORS.tertiary };
    } else {
      return { name: 'notifications', type: 'material', color: COLORS.info };
    }
  };

  const icon = getIcon();

  return (
    <TouchableOpacity
      style={[styles.container, !notification.read && styles.unreadContainer]}
      onPress={handlePress}
      activeOpacity={0.7}
    >
      <View style={[styles.iconContainer, { backgroundColor: `${icon.color}20` }]}>
        <Icon
          name={icon.name}
          type={icon.type}
          color={icon.color}
          size={22}
        />
      </View>
      
      <View style={styles.contentContainer}>
        <View style={styles.headerContainer}>
          <Text style={styles.title}>{notification.title}</Text>
          <Text style={styles.date}>{formatDate(notification.date)}</Text>
        </View>
        
        <Text style={styles.message} numberOfLines={2}>
          {notification.message}
        </Text>
      </View>
      
      {!notification.read && <View style={styles.unreadDot} />}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: SIZES.padding,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray20,
    marginBottom: SIZES.base / 2,
    borderRadius: Platform.OS === 'ios' ? 12 : 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 1,
  },
  unreadContainer: {
    backgroundColor: `${COLORS.primary}05`,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: SIZES.base * 2,
  },
  contentContainer: {
    flex: 1,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Platform.OS === 'ios' ? 6 : 4,
  },
  title: {
    ...FONTS.h4,
    color: COLORS.black,
    maxWidth: width * 0.6,
  },
  date: {
    ...FONTS.body5,
    color: COLORS.gray50,
  },
  message: {
    ...FONTS.body4,
    color: COLORS.gray70,
  },
  unreadDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: COLORS.primary,
    marginLeft: SIZES.base,
    alignSelf: 'center',
  },
});

export default NotificationItem;

import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Platform, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES, SHADOWS } from '../constants/theme';

const { width } = Dimensions.get('window');

const CampaignCard = ({ campaign, horizontal = false }) => {
  const router = useRouter();

  const handlePress = () => {
    router.push(`/campaign/${campaign.id}`);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  return (
    <TouchableOpacity
      style={[
        styles.container,
        horizontal ? styles.horizontalContainer : styles.verticalContainer,
        SHADOWS.medium
      ]}
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <Image
        source={{ uri: campaign.image }}
        style={horizontal ? styles.horizontalImage : styles.verticalImage}
        resizeMode="cover"
      />
      
      <View style={styles.contentContainer}>
        <View style={styles.brandContainer}>
          <Text style={styles.brandText}>{campaign.brand}</Text>
          {campaign.isNew && (
            <View style={styles.newBadge}>
              <Text style={styles.newBadgeText}>Yeni</Text>
            </View>
          )}
        </View>
        
        <Text style={styles.title} numberOfLines={2}>{campaign.title}</Text>
        
        <Text style={styles.description} numberOfLines={horizontal ? 2 : 3}>
          {campaign.description}
        </Text>
        
        <View style={styles.footer}>
          <View style={styles.dateContainer}>
            <Icon name="calendar" type="feather" size={14} color={COLORS.gray50} />
            <Text style={styles.dateText}>
              {formatDate(campaign.endDate)}
            </Text>
          </View>
          
          <TouchableOpacity style={styles.saveButton}>
            <Icon name="bookmark-outline" type="ionicon" size={20} color={COLORS.primary} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radius,
    overflow: 'hidden',
    marginBottom: SIZES.padding,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  verticalContainer: {
    width: '100%',
  },
  horizontalContainer: {
    width: Platform.OS === 'ios' ? width * 0.75 : 280,
    marginRight: SIZES.padding,
  },
  verticalImage: {
    width: '100%',
    height: 180,
    borderTopLeftRadius: SIZES.radius,
    borderTopRightRadius: SIZES.radius,
  },
  horizontalImage: {
    width: '100%',
    height: Platform.OS === 'ios' ? 160 : 140,
    borderTopLeftRadius: SIZES.radius,
    borderTopRightRadius: SIZES.radius,
  },
  contentContainer: {
    padding: SIZES.base * 2,
  },
  brandContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SIZES.base,
  },
  brandText: {
    ...FONTS.body5,
    color: COLORS.gray60,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  newBadge: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: SIZES.base,
    paddingVertical: 2,
    borderRadius: SIZES.base,
    marginLeft: SIZES.base,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 2,
  },
  newBadgeText: {
    ...FONTS.small,
    color: COLORS.white,
    fontWeight: 'bold',
  },
  title: {
    ...FONTS.h3,
    color: COLORS.black,
    marginBottom: SIZES.base,
  },
  description: {
    ...FONTS.body4,
    color: COLORS.gray50,
    marginBottom: SIZES.base * 2,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SIZES.base,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateText: {
    ...FONTS.body5,
    color: COLORS.gray50,
    marginLeft: 4,
  },
  saveButton: {
    padding: 4,
  },
});

export default CampaignCard;

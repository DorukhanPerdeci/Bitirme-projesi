import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES } from '../constants/theme';

const CategoryList = ({ categories, selectedCategory, onSelectCategory }) => {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}
    >
      <TouchableOpacity
        style={[
          styles.categoryItem,
          !selectedCategory && styles.selectedCategory
        ]}
        onPress={() => onSelectCategory(null)}
      >
        <Icon
          name="apps"
          type="ionicon"
          size={22}
          color={!selectedCategory ? COLORS.white : COLORS.primary}
          containerStyle={[
            styles.iconContainer,
            !selectedCategory && styles.selectedIconContainer
          ]}
        />
        <Text
          style={[
            styles.categoryText,
            !selectedCategory && styles.selectedCategoryText
          ]}
        >
          Tümü
        </Text>
      </TouchableOpacity>

      {categories.map((category) => (
        <TouchableOpacity
          key={category.id}
          style={[
            styles.categoryItem,
            selectedCategory === category.id && styles.selectedCategory
          ]}
          onPress={() => onSelectCategory(category.id)}
        >
          <Icon
            name={category.icon}
            type="material"
            size={22}
            color={selectedCategory === category.id ? COLORS.white : COLORS.primary}
            containerStyle={[
              styles.iconContainer,
              selectedCategory === category.id && styles.selectedIconContainer
            ]}
          />
          <Text
            style={[
              styles.categoryText,
              selectedCategory === category.id && styles.selectedCategoryText
            ]}
          >
            {category.name}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.base * 2,
  },
  categoryItem: {
    alignItems: 'center',
    marginRight: SIZES.padding,
    minWidth: 80,
  },
  selectedCategory: {
    transform: [{ scale: 1.05 }],
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: COLORS.gray10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: SIZES.base,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  selectedIconContainer: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  categoryText: {
    ...FONTS.body5,
    color: COLORS.gray70,
    textAlign: 'center',
  },
  selectedCategoryText: {
    color: COLORS.primary,
    fontWeight: 'bold',
  },
});

export default CategoryList;

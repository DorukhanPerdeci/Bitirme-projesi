import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES, SHADOWS } from '../constants/theme';

const InfluencerCard = ({ influencer, small = false }) => {
  const router = useRouter();

  const handlePress = () => {
    router.push(`/influencer/${influencer.id}`);
  };

  const formatFollowers = (count) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <TouchableOpacity
      style={[
        styles.container,
        small ? styles.smallContainer : {},
        SHADOWS.small
      ]}
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <Image
        source={{ uri: influencer.avatar }}
        style={[styles.avatar, small ? styles.smallAvatar : {}]}
      />
      
      <View style={styles.infoContainer}>
        <Text style={[styles.name, small ? styles.smallName : {}]} numberOfLines={1}>
          {influencer.name}
        </Text>
        
        <Text style={styles.username} numberOfLines={1}>
          {influencer.username}
        </Text>
        
        {!small && (
          <Text style={styles.category} numberOfLines={1}>
            {influencer.category}
          </Text>
        )}
        
        <View style={styles.followersContainer}>
          <Icon name="people" type="ionicon" size={small ? 12 : 14} color={COLORS.gray50} />
          <Text style={styles.followersText}>
            {formatFollowers(influencer.followers)} takipçi
          </Text>
        </View>
      </View>
      
      {!small && (
        <TouchableOpacity style={styles.followButton}>
          <Text style={styles.followButtonText}>Takip Et</Text>
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radius,
    padding: SIZES.base * 2,
    marginBottom: SIZES.padding,
    alignItems: 'center',
  },
  smallContainer: {
    padding: SIZES.base,
    marginRight: SIZES.base * 2,
    width: 160,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: SIZES.base * 2,
  },
  smallAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: SIZES.base,
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    ...FONTS.h3,
    color: COLORS.black,
  },
  smallName: {
    ...FONTS.h4,
  },
  username: {
    ...FONTS.body4,
    color: COLORS.gray50,
    marginBottom: 2,
  },
  category: {
    ...FONTS.body5,
    color: COLORS.primary,
    marginBottom: 4,
  },
  followersContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  followersText: {
    ...FONTS.body5,
    color: COLORS.gray50,
    marginLeft: 4,
  },
  followButton: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: SIZES.base * 2,
    paddingVertical: SIZES.base,
    borderRadius: SIZES.base * 3,
    marginLeft: SIZES.base,
  },
  followButtonText: {
    ...FONTS.body5,
    color: COLORS.white,
    fontWeight: 'bold',
  },
});

export default InfluencerCard;

# Katkıda Bulunma Rehberi

Slash App'e katkıda bulunmak istediğiniz için teşekkür ederiz! Aşağıda, projeye katkıda bulunmak için izlemeniz gereken adımları bulabilirsiniz.

## Geliştirme Ortamı Kurulumu

1. Repoyu klonlayın:
   ```
   git clone https://github.com/username/slash-app.git
   cd slash-app
   ```

2. Bağımlılıkları yükleyin:
   ```
   npm install
   ```

3. Uygulamayı başlatın:
   ```
   npm start
   ```

## Kod Standartları

- JavaScript dosyaları için ESLint kurallarına uyun
- Bileşenler için React Native'in en iyi uygulamalarını takip edin
- Tüm yeni özellikler için birim testleri yazın
- Tüm commit mesajları açıklayıcı olmalıdır

## Branching Stratejisi

- `main`: Üretim kodu
- `develop`: Geliştirme kodu
- Özellik dalları: `feature/özellik-adı`
- Hata düzeltme dalları: `bugfix/hata-adı`

## Pull Request Süreci

1. Kendi fork'unuzu oluşturun
2. Özellik veya hata düzeltmesi için bir dal oluşturun
3. Değişikliklerinizi yapın ve test edin
4. Değişikliklerinizi commit edin ve push edin
5. Pull request oluşturun

## Kod İnceleme Süreci

- Tüm pull request'ler en az bir gözden geçirme gerektirir
- Kodun kalitesi, okunabilirliği ve performansı kontrol edilir
- Testlerin geçmesi gerekir

## İletişim

Sorularınız veya önerileriniz için lütfen GitHub Issues kullanın veya ekiple iletişime geçin.

Katkılarınız için teşekkür ederiz!

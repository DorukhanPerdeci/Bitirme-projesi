import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, ActivityIndicator, Share } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES, SHADOWS } from '../../src/constants/theme';
import InfluencerCard from '../../src/components/InfluencerCard';
import CampaignCard from '../../src/components/CampaignCard';
import { campaigns, influencers } from '../../src/constants/mockData';

const CampaignDetailScreen = () => {
  const { t } = useTranslation();
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  const [campaign, setCampaign] = useState(null);
  const [campaignInfluencers, setCampaignInfluencers] = useState([]);
  const [relatedCampaigns, setRelatedCampaigns] = useState([]);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    // Mock veri yükleme simulasyonu
    const timer = setTimeout(() => {
      const foundCampaign = campaigns.find(item => item.id === id);
      setCampaign(foundCampaign);
      
      if (foundCampaign) {
        // Kampanya influencer'larını bul
        const foundInfluencers = influencers.filter(
          influencer => foundCampaign.influencers.includes(influencer.id)
        );
        setCampaignInfluencers(foundInfluencers);
        
        // İlgili kampanyaları bul (aynı kategoriden)
        const similar = campaigns.filter(
          item => item.category === foundCampaign.category && item.id !== foundCampaign.id
        ).slice(0, 3);
        setRelatedCampaigns(similar);
      }
      
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, [id]);

  const handleBack = () => {
    router.back();
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `${campaign.title} - ${campaign.description} #SlashApp`,
      });
    } catch (error) {
      console.log('Error sharing:', error);
    }
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  if (isLoading || !campaign) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: campaign.image }}
            style={styles.image}
            resizeMode="cover"
          />
          <View style={styles.overlay} />
          <TouchableOpacity style={styles.backButton} onPress={handleBack}>
            <Icon name="arrow-left" type="feather" size={24} color={COLORS.white} />
          </TouchableOpacity>
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.actionButton} onPress={handleShare}>
              <Icon name="share" type="feather" size={22} color={COLORS.white} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton} onPress={handleSave}>
              <Icon
                name={isSaved ? 'bookmark' : 'bookmark-outline'}
                type="ionicon"
                size={22}
                color={COLORS.white}
              />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.contentContainer}>
          <View style={styles.headerContainer}>
            <Text style={styles.brand}>{campaign.brand}</Text>
            <Text style={styles.title}>{campaign.title}</Text>
          </View>

          <View style={styles.infoContainer}>
            <View style={styles.infoItem}>
              <Icon name="calendar" type="feather" size={16} color={COLORS.gray50} />
              <Text style={styles.infoText}>
                {t('campaign.endDate')}: {formatDate(campaign.endDate)}
              </Text>
            </View>
            <View style={styles.infoItem}>
              <Icon name="tag" type="feather" size={16} color={COLORS.gray50} />
              <Text style={styles.infoText}>{campaign.category}</Text>
            </View>
          </View>

          <View style={styles.descriptionContainer}>
            <Text style={styles.sectionTitle}>{t('campaign.details')}</Text>
            <Text style={styles.description}>{campaign.description}</Text>
          </View>

          <View style={styles.termsContainer}>
            <Text style={styles.sectionTitle}>{t('campaign.terms')}</Text>
            <Text style={styles.terms}>{campaign.terms}</Text>
          </View>

          <View style={styles.howToUseContainer}>
            <Text style={styles.sectionTitle}>{t('campaign.howToUse')}</Text>
            <Text style={styles.howToUse}>{campaign.howToUse}</Text>
          </View>

          {campaignInfluencers.length > 0 && (
            <View style={styles.influencersContainer}>
              <Text style={styles.sectionTitle}>{t('campaign.influencers')}</Text>
              {campaignInfluencers.map(influencer => (
                <InfluencerCard key={influencer.id} influencer={influencer} />
              ))}
            </View>
          )}

          {relatedCampaigns.length > 0 && (
            <View style={styles.relatedContainer}>
              <Text style={styles.sectionTitle}>{t('campaign.relatedCampaigns')}</Text>
              {relatedCampaigns.map(item => (
                <CampaignCard key={item.id} campaign={item} />
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...FONTS.body3,
    color: COLORS.gray60,
    marginTop: SIZES.base,
  },
  imageContainer: {
    height: 250,
    width: '100%',
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
  },
  backButton: {
    position: 'absolute',
    top: SIZES.padding,
    left: SIZES.padding,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionButtons: {
    position: 'absolute',
    top: SIZES.padding,
    right: SIZES.padding,
    flexDirection: 'row',
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: SIZES.base,
  },
  contentContainer: {
    paddingHorizontal: SIZES.padding,
    paddingTop: SIZES.padding,
    paddingBottom: SIZES.padding * 2,
  },
  headerContainer: {
    marginBottom: SIZES.padding,
  },
  brand: {
    ...FONTS.body4,
    color: COLORS.primary,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: SIZES.base,
  },
  title: {
    ...FONTS.h1,
    color: COLORS.black,
  },
  infoContainer: {
    flexDirection: 'row',
    marginBottom: SIZES.padding,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: SIZES.padding,
  },
  infoText: {
    ...FONTS.body4,
    color: COLORS.gray50,
    marginLeft: 4,
  },
  sectionTitle: {
    ...FONTS.h3,
    color: COLORS.black,
    marginBottom: SIZES.base,
  },
  descriptionContainer: {
    marginBottom: SIZES.padding,
  },
  description: {
    ...FONTS.body3,
    color: COLORS.gray70,
    lineHeight: 22,
  },
  termsContainer: {
    marginBottom: SIZES.padding,
  },
  terms: {
    ...FONTS.body4,
    color: COLORS.gray70,
    lineHeight: 20,
  },
  howToUseContainer: {
    marginBottom: SIZES.padding,
  },
  howToUse: {
    ...FONTS.body4,
    color: COLORS.gray70,
    lineHeight: 20,
  },
  influencersContainer: {
    marginBottom: SIZES.padding,
  },
  relatedContainer: {
    marginTop: SIZES.padding,
  },
});

export default CampaignDetailScreen;

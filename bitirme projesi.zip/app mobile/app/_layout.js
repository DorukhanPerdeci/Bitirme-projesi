import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import '../src/i18n';

// Firebase entegrasyonu
import { initializeFirebase } from '../src/services/firebase/config';

export default function RootLayout() {
  // Firebase'i initialize et
  useEffect(() => {
    initializeFirebase();
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerShown: false }} />
    </SafeAreaProvider>
  );
}

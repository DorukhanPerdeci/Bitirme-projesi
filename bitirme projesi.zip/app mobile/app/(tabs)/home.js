import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Platform, Dimensions } from 'react-native';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES } from '../../src/constants/theme';
import CampaignCard from '../../src/components/CampaignCard';
import CategoryList from '../../src/components/CategoryList';
import InfluencerCard from '../../src/components/InfluencerCard';
import { campaigns, categories, influencers } from '../../src/constants/mockData';

const HomeScreen = () => {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [popularCampaigns, setPopularCampaigns] = useState([]);
  const [newCampaigns, setNewCampaigns] = useState([]);
  const [topInfluencers, setTopInfluencers] = useState([]);

  useEffect(() => {
    // Mock veri yükleme simulasyonu
    const timer = setTimeout(() => {
      setPopularCampaigns(campaigns.filter(campaign => campaign.isPopular));
      setNewCampaigns(campaigns.filter(campaign => campaign.isNew));
      setTopInfluencers(influencers.slice(0, 3));
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const filteredCampaigns = selectedCategory
    ? campaigns.filter(campaign => campaign.category === categories.find(cat => cat.id === selectedCategory)?.name)
    : campaigns;

  const renderHeader = () => {
    return (
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Merhaba 👋</Text>
          <Text style={styles.headerTitle}>{t('home.title')}</Text>
        </View>
        <TouchableOpacity style={styles.notificationButton}>
          <Icon name="notifications-outline" type="ionicon" size={24} color={COLORS.black} />
        </TouchableOpacity>
      </View>
    );
  };

  const renderPopularCampaigns = () => {
    return (
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t('home.popularCampaigns')}</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllText}>{t('home.viewAll')}</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalScrollContainer}
        >
          {popularCampaigns.map(campaign => (
            <CampaignCard key={campaign.id} campaign={campaign} horizontal />
          ))}
        </ScrollView>
      </View>
    );
  };

  const renderNewCampaigns = () => {
    return (
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t('home.newCampaigns')}</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllText}>{t('home.viewAll')}</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalScrollContainer}
        >
          {newCampaigns.map(campaign => (
            <CampaignCard key={campaign.id} campaign={campaign} horizontal />
          ))}
        </ScrollView>
      </View>
    );
  };

  const renderTopInfluencers = () => {
    return (
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Popüler Influencer'lar</Text>
          <TouchableOpacity>
            <Text style={styles.viewAllText}>{t('home.viewAll')}</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalScrollContainer}
        >
          {topInfluencers.map(influencer => (
            <InfluencerCard key={influencer.id} influencer={influencer} small />
          ))}
        </ScrollView>
      </View>
    );
  };

  const renderAllCampaigns = () => {
    return (
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Tüm Kampanyalar</Text>
        </View>

        <CategoryList
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        {filteredCampaigns.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Icon name="alert-circle" type="feather" size={50} color={COLORS.gray30} />
            <Text style={styles.emptyText}>{t('home.emptyList')}</Text>
          </View>
        ) : (
          filteredCampaigns.map(campaign => (
            <CampaignCard key={campaign.id} campaign={campaign} />
          ))
        )}
      </View>
    );
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {renderHeader()}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {renderPopularCampaigns()}
        {renderNewCampaigns()}
        {renderTopInfluencers()}
        {renderAllCampaigns()}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.gray10,
    paddingBottom: Platform.OS === 'ios' ? 85 : 60,
  },
  scrollContainer: {
    paddingBottom: Platform.OS === 'ios' ? SIZES.padding * 4 : SIZES.padding * 2,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...FONTS.body3,
    color: COLORS.gray60,
    marginTop: SIZES.base,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.padding,
    backgroundColor: COLORS.white,
  },
  greeting: {
    ...FONTS.body3,
    color: COLORS.gray60,
  },
  headerTitle: {
    ...FONTS.h1,
    color: COLORS.black,
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.gray10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionContainer: {
    marginTop: SIZES.padding,
    paddingHorizontal: SIZES.padding,
    backgroundColor: COLORS.white,
    paddingVertical: SIZES.padding,
    borderRadius: SIZES.radius,
    marginHorizontal: SIZES.base,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SIZES.padding,
  },
  sectionTitle: {
    ...FONTS.h2,
    color: COLORS.black,
  },
  viewAllText: {
    ...FONTS.body4,
    color: COLORS.primary,
  },
  horizontalScrollContainer: {
    paddingRight: SIZES.padding,
    paddingBottom: SIZES.base,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SIZES.padding * 2,
  },
  emptyText: {
    ...FONTS.body3,
    color: COLORS.gray50,
    marginTop: SIZES.base,
  },
});

export default HomeScreen;

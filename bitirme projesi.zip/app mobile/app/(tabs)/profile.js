import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Switch, ActivityIndicator } from 'react-native';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES, SHADOWS } from '../../src/constants/theme';

const ProfileScreen = () => {
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(true);

  useEffect(() => {
    // Mock veri yükleme simulasyonu
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const renderHeader = () => {
    return (
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t('profile.title')}</Text>
        <TouchableOpacity style={styles.settingsButton}>
          <Icon name="settings" type="feather" size={22} color={COLORS.black} />
        </TouchableOpacity>
      </View>
    );
  };

  const renderProfileInfo = () => {
    return (
      <View style={styles.profileContainer}>
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
          style={styles.profileImage}
        />
        <Text style={styles.profileName}>Ayşe Yılmaz</Text>
        <Text style={styles.profileEmail}>ayse.yilmaz@example.com</Text>
        <TouchableOpacity style={styles.editProfileButton}>
          <Text style={styles.editProfileButtonText}>{t('profile.editProfile')}</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const renderStatsSection = () => {
    return (
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>12</Text>
          <Text style={styles.statLabel}>Kaydedilen</Text>
        </View>
        <View style={[styles.statItem, styles.statItemBorder]}>
          <Text style={styles.statNumber}>5</Text>
          <Text style={styles.statLabel}>Takip Edilen</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>8</Text>
          <Text style={styles.statLabel}>Paylaşılan</Text>
        </View>
      </View>
    );
  };

  const renderSettingsSection = () => {
    return (
      <View style={styles.settingsContainer}>
        <Text style={styles.sectionTitle}>{t('profile.settings')}</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Icon name="moon" type="feather" size={20} color={COLORS.gray70} style={styles.settingIcon} />
            <Text style={styles.settingText}>{t('profile.darkMode')}</Text>
          </View>
          <Switch
            value={isDarkMode}
            onValueChange={setIsDarkMode}
            trackColor={{ false: COLORS.gray30, true: `${COLORS.primary}80` }}
            thumbColor={isDarkMode ? COLORS.primary : COLORS.white}
          />
        </View>
        
        <View style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Icon name="bell" type="feather" size={20} color={COLORS.gray70} style={styles.settingIcon} />
            <Text style={styles.settingText}>{t('profile.notifications')}</Text>
          </View>
          <Switch
            value={isNotificationsEnabled}
            onValueChange={setIsNotificationsEnabled}
            trackColor={{ false: COLORS.gray30, true: `${COLORS.primary}80` }}
            thumbColor={isNotificationsEnabled ? COLORS.primary : COLORS.white}
          />
        </View>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Icon name="globe" type="feather" size={20} color={COLORS.gray70} style={styles.settingIcon} />
            <Text style={styles.settingText}>{t('profile.language')}</Text>
          </View>
          <View style={styles.settingRight}>
            <Text style={styles.settingValue}>Türkçe</Text>
            <Icon name="chevron-right" type="feather" size={20} color={COLORS.gray50} />
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const renderSupportSection = () => {
    return (
      <View style={styles.supportContainer}>
        <Text style={styles.sectionTitle}>{t('common.support')}</Text>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Icon name="help-circle" type="feather" size={20} color={COLORS.gray70} style={styles.settingIcon} />
            <Text style={styles.settingText}>{t('profile.help')}</Text>
          </View>
          <Icon name="chevron-right" type="feather" size={20} color={COLORS.gray50} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Icon name="file-text" type="feather" size={20} color={COLORS.gray70} style={styles.settingIcon} />
            <Text style={styles.settingText}>{t('profile.termsOfService')}</Text>
          </View>
          <Icon name="chevron-right" type="feather" size={20} color={COLORS.gray50} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Icon name="lock" type="feather" size={20} color={COLORS.gray70} style={styles.settingIcon} />
            <Text style={styles.settingText}>{t('profile.privacyPolicy')}</Text>
          </View>
          <Icon name="chevron-right" type="feather" size={20} color={COLORS.gray50} />
        </TouchableOpacity>
      </View>
    );
  };

  const renderLogoutButton = () => {
    return (
      <TouchableOpacity style={styles.logoutButton}>
        <Icon name="log-out" type="feather" size={20} color={COLORS.error} style={styles.logoutIcon} />
        <Text style={styles.logoutText}>{t('profile.logout')}</Text>
      </TouchableOpacity>
    );
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {renderHeader()}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {renderProfileInfo()}
        {renderStatsSection()}
        {renderSettingsSection()}
        {renderSupportSection()}
        {renderLogoutButton()}
        <Text style={styles.versionText}>{t('profile.version')} 1.0.0</Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.gray10,
  },
  scrollContainer: {
    paddingBottom: SIZES.padding * 2,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...FONTS.body3,
    color: COLORS.gray60,
    marginTop: SIZES.base,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.padding,
    backgroundColor: COLORS.white,
  },
  headerTitle: {
    ...FONTS.h2,
    color: COLORS.black,
  },
  settingsButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.gray10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileContainer: {
    alignItems: 'center',
    paddingVertical: SIZES.padding * 2,
    backgroundColor: COLORS.white,
    marginBottom: SIZES.base,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: SIZES.padding,
  },
  profileName: {
    ...FONTS.h2,
    color: COLORS.black,
    marginBottom: SIZES.base,
  },
  profileEmail: {
    ...FONTS.body3,
    color: COLORS.gray50,
    marginBottom: SIZES.padding,
  },
  editProfileButton: {
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.base,
    borderRadius: SIZES.radius,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  editProfileButtonText: {
    ...FONTS.body4,
    color: COLORS.primary,
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    marginBottom: SIZES.padding,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: SIZES.padding,
  },
  statItemBorder: {
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: COLORS.gray20,
  },
  statNumber: {
    ...FONTS.h2,
    color: COLORS.black,
    marginBottom: SIZES.base,
  },
  statLabel: {
    ...FONTS.body4,
    color: COLORS.gray50,
  },
  sectionTitle: {
    ...FONTS.h3,
    color: COLORS.black,
    marginBottom: SIZES.base,
    paddingHorizontal: SIZES.padding,
    paddingTop: SIZES.padding,
  },
  settingsContainer: {
    backgroundColor: COLORS.white,
    marginBottom: SIZES.padding,
  },
  supportContainer: {
    backgroundColor: COLORS.white,
    marginBottom: SIZES.padding,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: SIZES.padding,
    paddingHorizontal: SIZES.padding,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray20,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    marginRight: SIZES.base * 2,
  },
  settingText: {
    ...FONTS.body3,
    color: COLORS.gray70,
  },
  settingRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingValue: {
    ...FONTS.body4,
    color: COLORS.gray50,
    marginRight: SIZES.base,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.white,
    paddingVertical: SIZES.padding,
    marginBottom: SIZES.padding,
  },
  logoutIcon: {
    marginRight: SIZES.base,
  },
  logoutText: {
    ...FONTS.body3,
    color: COLORS.error,
  },
  versionText: {
    ...FONTS.body5,
    color: COLORS.gray50,
    textAlign: 'center',
  },
});

export default ProfileScreen;

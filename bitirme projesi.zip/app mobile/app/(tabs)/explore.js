import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES } from '../../src/constants/theme';
import CampaignCard from '../../src/components/CampaignCard';
import CategoryList from '../../src/components/CategoryList';
import { campaigns, categories } from '../../src/constants/mockData';

const ExploreScreen = () => {
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [filteredCampaigns, setFilteredCampaigns] = useState([]);

  useEffect(() => {
    // Mock veri yükleme simulasyonu
    const timer = setTimeout(() => {
      setFilteredCampaigns(campaigns);
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    let results = campaigns;
    
    // Kategori filtreleme
    if (selectedCategory) {
      const categoryName = categories.find(cat => cat.id === selectedCategory)?.name;
      results = results.filter(campaign => campaign.category === categoryName);
    }
    
    // Arama filtreleme
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase().trim();
      results = results.filter(
        campaign =>
          campaign.title.toLowerCase().includes(query) ||
          campaign.description.toLowerCase().includes(query) ||
          campaign.brand.toLowerCase().includes(query)
      );
    }
    
    setFilteredCampaigns(results);
  }, [searchQuery, selectedCategory]);

  const renderHeader = () => {
    return (
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t('common.search')}</Text>
      </View>
    );
  };

  const renderSearchBar = () => {
    return (
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Icon name="search" type="feather" size={20} color={COLORS.gray50} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder={t('common.search')}
            placeholderTextColor={COLORS.gray50}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Icon name="x" type="feather" size={20} color={COLORS.gray50} />
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity style={styles.filterButton}>
          <Icon name="sliders" type="feather" size={20} color={COLORS.white} />
        </TouchableOpacity>
      </View>
    );
  };

  const renderEmptyResult = () => {
    return (
      <View style={styles.emptyContainer}>
        <Icon name="search" type="feather" size={50} color={COLORS.gray30} />
        <Text style={styles.emptyText}>Aradığınız kriterlere uygun kampanya bulunamadı.</Text>
        <TouchableOpacity
          style={styles.resetButton}
          onPress={() => {
            setSearchQuery('');
            setSelectedCategory(null);
          }}
        >
          <Text style={styles.resetButtonText}>Filtreleri Temizle</Text>
        </TouchableOpacity>
      </View>
    );
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {renderHeader()}
      {renderSearchBar()}
      <CategoryList
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />
      
      {filteredCampaigns.length === 0 ? (
        renderEmptyResult()
      ) : (
        <FlatList
          data={filteredCampaigns}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <CampaignCard campaign={item} />}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.gray10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...FONTS.body3,
    color: COLORS.gray60,
    marginTop: SIZES.base,
  },
  header: {
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.padding,
    backgroundColor: COLORS.white,
  },
  headerTitle: {
    ...FONTS.h2,
    color: COLORS.black,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.base * 2,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray20,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.gray10,
    borderRadius: SIZES.radius,
    paddingHorizontal: SIZES.base * 2,
    height: 46,
    marginRight: SIZES.base,
  },
  searchIcon: {
    marginRight: SIZES.base,
  },
  searchInput: {
    flex: 1,
    ...FONTS.body3,
    color: COLORS.black,
    height: '100%',
  },
  filterButton: {
    backgroundColor: COLORS.primary,
    width: 46,
    height: 46,
    borderRadius: SIZES.radius,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContainer: {
    paddingHorizontal: SIZES.padding,
    paddingTop: SIZES.base,
    paddingBottom: SIZES.padding * 2,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SIZES.padding * 2,
  },
  emptyText: {
    ...FONTS.body3,
    color: COLORS.gray60,
    textAlign: 'center',
    marginTop: SIZES.padding,
    marginBottom: SIZES.padding,
  },
  resetButton: {
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.base,
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radius,
  },
  resetButtonText: {
    ...FONTS.body4,
    color: COLORS.white,
    fontWeight: 'bold',
  },
});

export default ExploreScreen;

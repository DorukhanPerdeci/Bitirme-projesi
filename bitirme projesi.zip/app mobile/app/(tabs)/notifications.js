import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, Platform, Dimensions } from 'react-native';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from 'react-native-elements';
import { COLORS, FONTS, SIZES } from '../../src/constants/theme';
import NotificationItem from '../../src/components/NotificationItem';
import { notifications } from '../../src/constants/mockData';

const { width, height } = Dimensions.get('window');

const NotificationsScreen = () => {
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(true);
  const [notificationsList, setNotificationsList] = useState([]);

  useEffect(() => {
    // Mock veri yükleme simulasyonu
    const timer = setTimeout(() => {
      setNotificationsList(notifications);
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const renderHeader = () => {
    return (
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t('notifications.title')}</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity style={styles.headerButton}>
            <Text style={styles.headerButtonText}>{t('notifications.markAllAsRead')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton}>
            <Icon name="trash-2" type="feather" size={20} color={COLORS.gray50} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const renderEmptyComponent = () => {
    return (
      <View style={styles.emptyContainer}>
        <Icon name="bell-off" type="feather" size={50} color={COLORS.gray30} />
        <Text style={styles.emptyText}>{t('notifications.emptyList')}</Text>
      </View>
    );
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {renderHeader()}
      <FlatList
        data={notificationsList}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <NotificationItem notification={item} />}
        contentContainerStyle={styles.listContainer}
        ListEmptyComponent={renderEmptyComponent}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.gray10,
    paddingBottom: Platform.OS === 'ios' ? 85 : 60,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...FONTS.body3,
    color: COLORS.gray60,
    marginTop: SIZES.base,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SIZES.padding,
    paddingVertical: SIZES.padding,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  headerTitle: {
    ...FONTS.h2,
    color: COLORS.black,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerButton: {
    marginLeft: SIZES.base * 2,
    padding: SIZES.base,
  },
  headerButtonText: {
    ...FONTS.body4,
    color: COLORS.primary,
  },
  listContainer: {
    flexGrow: 1,
    paddingHorizontal: SIZES.padding,
    paddingBottom: Platform.OS === 'ios' ? SIZES.padding * 4 : SIZES.padding * 2,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: SIZES.padding * 4,
  },
  emptyText: {
    ...FONTS.body3,
    color: COLORS.gray50,
    marginTop: SIZES.base * 2,
  },
});

export default NotificationsScreen;

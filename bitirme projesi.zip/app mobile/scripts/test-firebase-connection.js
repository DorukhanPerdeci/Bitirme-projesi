// Firebase bağlantı testi
const { initializeApp } = require('firebase/app');
const { 
  getFirestore, 
  collection, 
  getDocs, 
  query, 
  limit 
} = require('firebase/firestore');
const {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut
} = require('firebase/auth');

// Firebase yapılandırması
const firebaseConfig = {
  apiKey: "AIzaSyD47YnhTe4ikGTnv7X3PPpzH1NsZs6Ltnc",
  authDomain: "slash-app-dc4d1.firebaseapp.com",
  projectId: "slash-app-dc4d1",
  storageBucket: "slash-app-dc4d1.firebasestorage.app",
  messagingSenderId: "403111331493",
  appId: "1:403111331493:web:9491c7c1d05a20a2d3ef4c",
  measurementId: "G-R32G6FGTME"
};

// Firebase uygulamasını başlat
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Test fonksiyonları
async function testFirebaseConnection() {
  console.log('🔥 Firebase Bağlantı Testi Başlatılıyor...');
  console.log('------------------------------------');
  
  try {
    // Firestore bağlantısını test et
    console.log('📊 Firestore Bağlantısı Test Ediliyor...');
    const testQuery = query(collection(db, 'test'), limit(1));
    const testSnapshot = await getDocs(testQuery);
    
    if (!testSnapshot.empty) {
      console.log('✅ Firestore bağlantısı başarılı!');
      console.log(`📄 Test dökümanı: ${JSON.stringify(testSnapshot.docs[0].data())}`);
    } else {
      console.log('✅ Firestore bağlantısı başarılı, ancak test dökümanı bulunamadı.');
    }
  } catch (error) {
    console.error('❌ Firestore bağlantı hatası:', error);
  }
  
  console.log('------------------------------------');
  
  // Kategorileri getir
  try {
    console.log('🏷️  Kategoriler Getiriliyor...');
    const kategorilerQuery = query(collection(db, 'kategoriler'), limit(10));
    const kategorilerSnapshot = await getDocs(kategorilerQuery);
    
    if (!kategorilerSnapshot.empty) {
      console.log(`✅ ${kategorilerSnapshot.size} kategori bulundu:`);
      
      kategorilerSnapshot.forEach((doc) => {
        console.log(`- ${doc.data().ad}`);
      });
    } else {
      console.log('❌ Hiç kategori bulunamadı.');
    }
  } catch (error) {
    console.error('❌ Kategori getirme hatası:', error);
  }
  
  console.log('------------------------------------');
  
  // Kampanyaları getir
  try {
    console.log('🎯 Kampanyalar Getiriliyor...');
    const kampanyalarQuery = query(collection(db, 'kampanyalar'), limit(10));
    const kampanyalarSnapshot = await getDocs(kampanyalarQuery);
    
    if (!kampanyalarSnapshot.empty) {
      console.log(`✅ ${kampanyalarSnapshot.size} kampanya bulundu:`);
      
      kampanyalarSnapshot.forEach((doc) => {
        console.log(`- ${doc.data().baslik} (${doc.data().marka})`);
      });
    } else {
      console.log('❌ Hiç kampanya bulunamadı.');
    }
  } catch (error) {
    console.error('❌ Kampanya getirme hatası:', error);
  }
  
  console.log('------------------------------------');
  
  // Influencer'ları getir
  try {
    console.log('👤 Influencer\'lar Getiriliyor...');
    const influencerlarQuery = query(collection(db, 'influencerlar'), limit(10));
    const influencerlarSnapshot = await getDocs(influencerlarQuery);
    
    if (!influencerlarSnapshot.empty) {
      console.log(`✅ ${influencerlarSnapshot.size} influencer bulundu:`);
      
      influencerlarSnapshot.forEach((doc) => {
        console.log(`- ${doc.data().isim} (@${doc.data().kullaniciAdi})`);
      });
    } else {
      console.log('❌ Hiç influencer bulunamadı.');
    }
  } catch (error) {
    console.error('❌ Influencer getirme hatası:', error);
  }
  
  console.log('------------------------------------');
  
  // Auth testleri
  try {
    console.log('🔐 Authentication Testi Başlatılıyor...');
    
    // Test kullanıcısı oluştur
    console.log('👤 Test kullanıcısı oluşturuluyor...');
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, 'test@example.com', 'Test123!');
      console.log('✅ Test kullanıcısı oluşturuldu:', userCredential.user.uid);
    } catch (error) {
      if (error.code === 'auth/email-already-in-use') {
        console.log('ℹ️ Test kullanıcısı zaten mevcut, giriş yapılacak.');
      } else {
        throw error;
      }
    }
    
    // Test kullanıcısı ile giriş yap
    console.log('🔑 Test kullanıcısı ile giriş yapılıyor...');
    const signInResult = await signInWithEmailAndPassword(auth, 'test@example.com', 'Test123!');
    console.log('✅ Giriş başarılı:', signInResult.user.uid);
    
    // Çıkış yap
    console.log('🚪 Çıkış yapılıyor...');
    await signOut(auth);
    console.log('✅ Çıkış başarılı!');
    
    console.log('✅ Authentication testi başarılı!');
  } catch (error) {
    console.error('❌ Authentication test hatası:', error);
  }
  
  console.log('------------------------------------');
  console.log('🎉 Firebase Bağlantı Testi Tamamlandı!');
}

// Testi çalıştır
testFirebaseConnection();

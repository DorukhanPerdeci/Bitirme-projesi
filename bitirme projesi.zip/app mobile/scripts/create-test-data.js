// Firebase test verileri oluşturma scripti
const { initializeApp } = require('firebase/app');
const { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  serverTimestamp 
} = require('firebase/firestore');

// Firebase yapılandırması
const firebaseConfig = {
  apiKey: "AIzaSyD47YnhTe4ikGTnv7X3PPpzH1NsZs6Ltnc",
  authDomain: "slash-app-dc4d1.firebaseapp.com",
  projectId: "slash-app-dc4d1",
  storageBucket: "slash-app-dc4d1.firebasestorage.app",
  messagingSenderId: "403111331493",
  appId: "1:403111331493:web:9491c7c1d05a20a2d3ef4c",
  measurementId: "G-R32G6FGTME"
};

// Firebase uygulamasını başlat
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Test verileri
const testData = {
  // Test bağlantı dökümanı
  test: {
    connection: {
      status: 'active',
      timestamp: serverTimestamp()
    }
  },
  
  // Kategoriler
  kategoriler: [
    {
      id: 'moda',
      ad: 'Moda',
      aciklama: 'Moda ve giyim kampanyaları',
      resimUrl: 'https://example.com/images/moda.jpg',
      popülerlik: 98,
      sira: 1
    },
    {
      id: 'teknoloji',
      ad: 'Teknoloji',
      aciklama: 'Teknoloji ve elektronik kampanyaları',
      resimUrl: 'https://example.com/images/teknoloji.jpg',
      popülerlik: 95,
      sira: 2
    },
    {
      id: 'guzellik',
      ad: 'Güzellik',
      aciklama: 'Kozmetik ve güzellik kampanyaları',
      resimUrl: 'https://example.com/images/guzellik.jpg',
      popülerlik: 90,
      sira: 3
    },
    {
      id: 'yemek',
      ad: 'Yemek',
      aciklama: 'Yemek ve restoran kampanyaları',
      resimUrl: 'https://example.com/images/yemek.jpg',
      popülerlik: 85,
      sira: 4
    },
    {
      id: 'seyahat',
      ad: 'Seyahat',
      aciklama: 'Seyahat ve tatil kampanyaları',
      resimUrl: 'https://example.com/images/seyahat.jpg',
      popülerlik: 80,
      sira: 5
    }
  ],
  
  // Kampanyalar
  kampanyalar: [
    {
      id: 'kampanya1',
      baslik: 'Yaz Koleksiyonu İndirimi',
      marka: 'ModaVIP',
      aciklama: 'Yaz koleksiyonunda %50\'ye varan indirimler',
      detay: 'Tüm yaz koleksiyonunda geçerli olan bu kampanya ile en trend parçalara yarı fiyatına sahip olabilirsiniz.',
      resimUrl: 'https://example.com/images/kampanya1.jpg',
      baslangicTarihi: new Date('2025-03-01'),
      bitisTarihi: new Date('2025-04-01'),
      kategoriId: 'moda',
      influencerIds: ['influencer1', 'influencer3'],
      begeniSayisi: 1250,
      goruntulemeSayisi: 5400,
      kaydetmeSayisi: 320,
      olusturulmaTarihi: serverTimestamp()
    },
    {
      id: 'kampanya2',
      baslik: 'Akıllı Telefon Kampanyası',
      marka: 'TechStore',
      aciklama: 'En yeni akıllı telefonlarda 2000 TL indirim',
      detay: 'Seçili akıllı telefon modellerinde geçerli olan bu kampanya ile teknolojinin en son yeniliklerine uygun fiyatlarla sahip olabilirsiniz.',
      resimUrl: 'https://example.com/images/kampanya2.jpg',
      baslangicTarihi: new Date('2025-03-10'),
      bitisTarihi: new Date('2025-03-25'),
      kategoriId: 'teknoloji',
      influencerIds: ['influencer2'],
      begeniSayisi: 980,
      goruntulemeSayisi: 4200,
      kaydetmeSayisi: 210,
      olusturulmaTarihi: serverTimestamp()
    },
    {
      id: 'kampanya3',
      baslik: 'Cilt Bakım Seti Hediyeli',
      marka: 'BeautySkin',
      aciklama: 'Alışverişinize özel cilt bakım seti hediye',
      detay: '250 TL ve üzeri alışverişlerinizde 5 parçalı cilt bakım seti hediye. Kampanya stoklarla sınırlıdır.',
      resimUrl: 'https://example.com/images/kampanya3.jpg',
      baslangicTarihi: new Date('2025-03-05'),
      bitisTarihi: new Date('2025-03-20'),
      kategoriId: 'guzellik',
      influencerIds: ['influencer3', 'influencer4'],
      begeniSayisi: 1500,
      goruntulemeSayisi: 6800,
      kaydetmeSayisi: 450,
      olusturulmaTarihi: serverTimestamp()
    }
  ],
  
  // Influencer'lar
  influencerlar: [
    {
      id: 'influencer1',
      isim: 'Ayşe Moda',
      kullaniciAdi: 'aysemoda',
      bio: 'Moda ve stil konusunda içerik üretiyorum',
      profilResmiUrl: 'https://example.com/images/influencer1.jpg',
      takipciSayisi: 250000,
      kategori: 'moda',
      sosyalMedya: {
        instagram: 'aysemoda',
        youtube: 'AyseModa',
        tiktok: 'aysemoda'
      },
      olusturulmaTarihi: serverTimestamp()
    },
    {
      id: 'influencer2',
      isim: 'Tekno Ali',
      kullaniciAdi: 'teknoali',
      bio: 'Teknoloji ve gadget inceleme videoları',
      profilResmiUrl: 'https://example.com/images/influencer2.jpg',
      takipciSayisi: 500000,
      kategori: 'teknoloji',
      sosyalMedya: {
        instagram: 'teknoali',
        youtube: 'TeknoAliTV',
        twitter: 'teknoali'
      },
      olusturulmaTarihi: serverTimestamp()
    },
    {
      id: 'influencer3',
      isim: 'Güzel Dünya',
      kullaniciAdi: 'guzeldunyam',
      bio: 'Makyaj ve cilt bakımı ipuçları',
      profilResmiUrl: 'https://example.com/images/influencer3.jpg',
      takipciSayisi: 320000,
      kategori: 'guzellik',
      sosyalMedya: {
        instagram: 'guzeldunyam',
        youtube: 'GuzelDunyam',
        tiktok: 'guzeldunyam'
      },
      olusturulmaTarihi: serverTimestamp()
    },
    {
      id: 'influencer4',
      isim: 'Lezzet Durağı',
      kullaniciAdi: 'lezzetduragi',
      bio: 'Yemek tarifleri ve restoran tavsiyeleri',
      profilResmiUrl: 'https://example.com/images/influencer4.jpg',
      takipciSayisi: 180000,
      kategori: 'yemek',
      sosyalMedya: {
        instagram: 'lezzetduragi',
        youtube: 'LezzetDuragi',
        twitter: 'lezzetduragi'
      },
      olusturulmaTarihi: serverTimestamp()
    }
  ]
};

// Verileri Firestore'a yaz
async function createTestData() {
  try {
    console.log('Test verileri oluşturuluyor...');
    
    // Test bağlantı dökümanı
    await setDoc(doc(db, 'test', 'connection'), testData.test.connection);
    console.log('✅ Test bağlantı dökümanı oluşturuldu');
    
    // Kategoriler
    for (const kategori of testData.kategoriler) {
      const { id, ...data } = kategori;
      await setDoc(doc(db, 'kategoriler', id), data);
    }
    console.log(`✅ ${testData.kategoriler.length} kategori oluşturuldu`);
    
    // Kampanyalar
    for (const kampanya of testData.kampanyalar) {
      const { id, ...data } = kampanya;
      await setDoc(doc(db, 'kampanyalar', id), data);
    }
    console.log(`✅ ${testData.kampanyalar.length} kampanya oluşturuldu`);
    
    // Influencer'lar
    for (const influencer of testData.influencerlar) {
      const { id, ...data } = influencer;
      await setDoc(doc(db, 'influencerlar', id), data);
    }
    console.log(`✅ ${testData.influencerlar.length} influencer oluşturuldu`);
    
    console.log('✅ Tüm test verileri başarıyla oluşturuldu!');
  } catch (error) {
    console.error('❌ Test verileri oluşturulurken hata:', error);
  }
}

// Test verilerini oluştur
createTestData();
